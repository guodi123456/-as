import Taro, { Component } from '@tarojs/taro';
import { View, Button } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import _ from 'lodash';
import { CardHeader, MJInput, TemplateItem } from '../../components';
import { handelChangeActiveDetailData, saveActive } from '../../actions/actives'
import './index.scss';

@connect(({ actives }) => ({
  activeDetail: _.get(actives, 'active_detail', {}),
  id: _.get(actives, 'active_detail.id', ''),
}), (dispatch) => ({
  onHandelChangeActiveDetailData (query) {
    dispatch(handelChangeActiveDetailData(query))
  },
  onSaveActive (data) {
    dispatch(saveActive(data))
  },
}))
class AddCustom extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectType: null
  }
}
  static defaultProps = {
      prefix: 'add-custom',
    }
    config = {
      navigationBarTitleText: '新增模块',
      navigationBarBackgroundColor: '#FAFAFA',
    }

   // 获取ModalType 
   getModalType = (modalType) => {
    this.setState({
      selectType: modalType,
    })
  }

  //   确认
  addModal = () => {
    const { selectType, title } = this.state;
    const { activeDetail, id } = this.props;
    const moduleDetail = _.get(activeDetail, 'module', []);
    const value = {
      title,
      module_type: selectType
    }
    const path = String('active_detail.module.'.concat(moduleDetail.length));
    this.props.onHandelChangeActiveDetailData({
      path,
      value
    });
    this.props.onSaveActive({ ...activeDetail, id});  
    Taro.navigateBack();
  }
// 更改modalName 
  changeModalName = (e) => {
    const value = e.target.value;
    this.setState({
      title: value,
    })
  }


  render () {
    const { prefix='add-custom', } = this.props;
    const { selectType, title } = this.state;
    return (
      <View className={prefix}>
        <View className={`${prefix}-header`}>
          <View className={`${prefix}-header-title`}>
            <CardHeader
              title='模块标题'
              color='#EB0911'
            ></CardHeader>
          </View>
          <View className={`${prefix}-header-input`}>
            <MJInput
              placeholder='请输入新增模块标题，最多10字'
              type='text'
              option='name'
              showNumber={false}
              maxLength={10}
              style='width: 100%'
              onInputChange={this.changeModalName.bind(this)}
            />
          </View>
        </View>
        <View className={`${prefix}-style`}>
          <View className={`${prefix}-style-title`}> 
            <CardHeader
              title='模块样式'
              color='#EB0911'
            ></CardHeader>
          </View>
          <View className={`${prefix}-style-img`}>
            <View className={`${prefix}-style-img-title`}>
              样式一：
            </View>
            <View className={`${prefix}-style-img-content`}>
              <TemplateItem
                onGetModalType={this.getModalType.bind(this)}
                selectType={selectType}
                type={0}
              >
              </TemplateItem>
            </View>
            <View className={`${prefix}-style-img-info`}>
              <View className={`${prefix}-style-img-info-icon`}>*</View>
              <View className={`${prefix}-style-img-info-text`}>建议填写嘉宾、参展商等信息</View>
            </View>
          </View>
          <View className={`${prefix}-style-phone`}>
            <View className={`${prefix}-style-phone-title`}>
              样式二：
            </View>
            <View className={`${prefix}-style-phone-content`}>
              <TemplateItem
                onGetModalType={this.getModalType.bind(this)}
                selectType={selectType}
                type={1}
              >
              </TemplateItem>
            </View>
            <View className={`${prefix}-style-phone-info`}>
            <View className={`${prefix}-style-phone-info-icon`}>*</View>
            <View className={`${prefix}-style-phone-info-text`}>建议填写活动联系人等信息</View>
            </View>
          </View>
          <View className={`${prefix}-style-define`}>
            <View className={`${prefix}-style-define-title`}>
              样式三：
            </View>
            <View className={`${prefix}-style-define-content`}>
              <TemplateItem
                onGetModalType={this.getModalType.bind(this)}
                selectType={selectType}
                type={2}
              >
              </TemplateItem>
            </View>
          </View>
          <View className={`${prefix}-style-btn`}>
            <Button
              className={`${prefix}-style-btn-but`}
              onClick={this.addModal.bind(this)}
              disabled={selectType === null || !title}
            >确定</Button>
          </View>

        </View>
      </View>
    )
  }
}

export default AddCustom
