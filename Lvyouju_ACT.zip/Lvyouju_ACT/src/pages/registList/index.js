import Taro, { Component } from '@tarojs/taro';
import { connect } from '@tarojs/redux';
import { View } from '@tarojs/components';
import _ from 'lodash';
import { PeopleList } from '../../components';
import { searchPeopleList } from '../../utils'
import { requestContactInfo } from "../../actions/actives";
import './index.scss';

let inputVal = '';
@connect(({ actives }) => ({
  contactData: _.get(actives, 'contact_data', {}),
  }), (dispatch) => ({
    onRequestContactInfo (query) {
      dispatch(requestContactInfo(query))
    },
  }))
class RegistList extends Component {
  constructor(props) {
    super(props);
    const params = _.get(this.$router, 'params', {});
    this.state = {
      searchList: [],
      isSearch: false,
      active_id: params.active_id,
      state_tab: +params.activeType,
    }
  }
    static defaultProps = {
      prefix: 'regist-info',
    }
    config = {
    navigationBarBackgroundColor: '#FAFAFA',
    navigationBarTitleText: '报名名单'
  }

  componentWillReceiveProps (nextProps) {
    console.log(this.props, nextProps)
  }

  componentWillMount () {
    // 获取审核名单信息
    this.getRequestinfo()
  }

  getRequestinfo = () => {
    this.props.onRequestContactInfo({
      mode: 3,
      id: this.state.active_id,
      status: this.state.state_tab,
      filter: {key: ''}
    });
  }

  componentDidShow = () => {
    this.interval = setInterval(() => this.getRequestinfo(), 60000)
  }

  componentWillUnmount = () => {
    clearInterval(this.interval);
  }
  componentDidHide = () => {
    clearInterval(this.interval);
  }

   // 获取搜索框value 
   getSearchCont = (val) => {
    inputVal = val;
    if (!val.trim()) {
      this.setState({
        isSearch: false
      })
    }
  }
  // 搜索查询
  seachClick = async (mode) => {
    if(!inputVal.trim()) {
      return;
    }
    const { active_id, state_tab } = this.state;
    const res = await searchPeopleList(active_id, mode, inputVal, +state_tab);
    this.setState({
      searchList: res.data.data.list,
      isSearch: true
    })
  }

  render () {
    const { prefix='regist-info', contactData } = this.props;
    const { isSearch, searchList, active_id } = this.state;
    const list = isSearch ? searchList : contactData;
    return (
      <View className={prefix}>
        <PeopleList
          people_list={list}
          num={list.length}
          title='已报名'
          isSearched={isSearch}
          activeId={active_id}
          onInputChange={this.getSearchCont.bind(this)}
          onInputClick={this.seachClick.bind(this, 3)}
        />
      </View>
    )
  }
}

export default RegistList
