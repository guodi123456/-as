import Taro, { Component } from '@tarojs/taro';
import { connect } from '@tarojs/redux';
import { View, Image, Text} from '@tarojs/components';
import _ from 'lodash';
import { requestPeopleInfo } from "../../actions/actives";
import { AddButton } from '../../components';
import xiaZaiImg from '../../assets/image/xiazai.png';
import request from '../../utils/request'
import './index.scss';

@connect(({ actives, auth }) => ({
  peopleInfo: _.get(actives, 'people_info', {}),
  token : _.get(auth, 'token', ''),
  ptid : _.get(auth, 'agency_info.ptid', ''),
  uid : _.get(auth, 'uid', ''),
}), (dispatch) => ({
  onRequestPeopleInfo(query) {
    dispatch(requestPeopleInfo(query))
  }
}))
class DownloadInfo extends Component {
  constructor(props) {
    super(props);
    const params = _.get(this.$router, 'params', {});
    const { token, uid, ptid } = this.props;
    this.state = {
      info: {
        name: '',
        url: '',
        sizeOut: ''
      },
      pageUrl: `http://acttest.mioji.com/act/#/file/${params.active_id}/${token}/${uid}/${ptid}`
    }
  }
  static defaultProps = {
    prefix: 'download-info',
  }
  config = {
    navigationBarTitleText: '文件下载'
  }
  componentWillMount = async () => {
    const params = _.get(this.$router, 'params', {});
    const res = await request({
      type: 'api45715',
      query: {
        id: params.active_id
      }
    })
    this.setState({
      info: {
        ...res.data.data
      }
    })
  }

  copyUrl = () => {
    const { pageUrl } = this.state;
    Taro.setClipboardData({data: pageUrl}).then(() => {
      Taro.showToast({
        title: '复制成功',
        icon: 'none'
      })
    })
  }

  render() {
    const { prefix='download-info' } = this.props;
    const { url, name, sizeOut } = this.state.info;
    return (
      <View className={prefix}>
        <Image
          src={xiaZaiImg}
          className={`${prefix}-img`}
        />
        <View className={`${prefix}-title`}>{name}</View>
        <Text className={`${prefix}-size`}>{sizeOut}</Text>
        <Text className={`${prefix}-tips`}>点击复制链接后，在网页中打开进行下载</Text>
        <Text className={`${prefix}-link`}>{url}</Text>
        <View className={`${prefix}-button`}>
          <AddButton
            iconType='hdlu_fuzhi'
            type='confirm'
            title='复制链接'
            color='#fff'
            size={56}
            onAddActive={this.copyUrl.bind(this)}
          />
        </View>
      </View>
    )
  }

}

export default DownloadInfo