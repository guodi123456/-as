import Taro, { Component } from '@tarojs/taro';
import { View, Text } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import _ from 'lodash';
import { MJInput, CardHeader, UploadImage, MJButton } from '../../components';
import { handelChangeActiveDetailData, saveActive } from '../../actions/actives';
import './index.scss';

@connect(({ actives }) => ({
  activeDetail: _.get(actives, 'active_detail', {}),
  id: _.get(actives, 'active_detail.id', ''),
}), (dispatch) => ({
  onHandelChangeActiveDetailData (query) {
    dispatch(handelChangeActiveDetailData(query))
  },
  onSaveActive (data) {
    dispatch(saveActive(data))
  },
}))
class AddGuest extends Component {
  static defaultProps = {
    prefix: 'add-guest',
  }
  constructor(props) {
    super(props);
    this.state = {
      initData: {
        name: '',
        img: '',
        desc: ''
      }
    }
  }
  config = {
    navigationBarTitleText: '新增嘉宾',
    navigationBarBackgroundColor: '#FAFAFA',
  }
  componentDidShow () {
   }

  componentDidHide () { }

  componentDidMount () {
    const { moduleDetail, moduleIndex, listIndex, type } = this.props;
    const moduleList = _.get(moduleDetail, `${moduleIndex}.list.${listIndex}`, []);
    if (type === 'edit') {
      this.setState({
        initData: moduleList
      })
    }
  }

  componentDidMount () {
    const { activeDetail } = this.props;
    const type = _.get(this.$router, 'params.type', {});
    const moduleIndex = _.get(this.$router, 'params.moduleIndex', {});
    const listIndex = _.get(this.$router, 'params.listIndex', {});
    const moduleList = _.get(activeDetail, `module.${moduleIndex}.list.${listIndex}`, []);
    if (type === 'edit') {
      this.setState({
        initData: moduleList
      })
    }
  }

  // 编辑module信息
  onHandelChange = (option, e) => {
    const value = option  === 'img' ? e : e.target.value;
    const { initData } = this.state;
    initData[option] = value;
    this.setState({
      initData
    })
  }

  //  确定
  saveClick = () => {
    const { initData } = this.state;
    this.saveEditModule(initData);
  }

  //保存编辑内容
  saveEditModule = (initData) => {
    const { activeDetail, id } = this.props;
    const moduleDetail = _.get(activeDetail, 'module', []);
    const type = _.get(this.$router, 'params.type', '');
    const moduleIndex = parseInt(_.get(this.$router, 'params.moduleIndex', ''));
    if (type === 'add') {
      const list = _.get(moduleDetail, `${moduleIndex}.list`, [])
      const path = `active_detail.module.${moduleIndex}.list`;
      list.push(initData);
      this.props.onHandelChangeActiveDetailData({
        path,
        value: list,
      })
    } else if (type === 'edit'){
      const listIndex = parseInt(_.get(this.$router, 'params.listIndex', {}));
      const path = `active_detail.module.${moduleIndex}.list.${listIndex}`
      this.props.onHandelChangeActiveDetailData({
        path,
        value: initData
      });
    }
    this.props.onSaveActive({ ...activeDetail, id}); 
    Taro.navigateBack();
  }

  render () {
    const { prefix='add-guest' } = this.props;
    const { initData } = this.state;
    const { name, img, desc } = initData;
    const isClick = !name || !img || !desc;
    return (
      <View className={prefix}>
        <View className={`${prefix}-title`}>
          <CardHeader
            title='填写信息'
            color='#EB0911'
          ></CardHeader>
        </View>
        <View className={`${prefix}-header`}>
          <View className={`${prefix}-header-label`}>上传头像</View>
          <View className={`${prefix}-header-imgbox`}>
            <UploadImage
              titleType={1}
              title='上传头像'
              img={img}
              onChangeImage={this.onHandelChange.bind(this, 'img')}
            >
            </UploadImage>
          </View>
          <Text className={`${prefix}-header-tips`}>*建议上传图片比例为1:1</Text>
        </View>
        <View className={`${prefix}-name`}>
          <MJInput
            show
            required={1}
            value={name}
            label='嘉宾姓名'
            placeholder='请填写短文本，最多10字'
            maxLength={10}
            onInputChange={this.onHandelChange.bind(this, 'name')}
          />
        </View>
        <View className={`${prefix}-brief `}>
          <MJInput
            show
            required={1}
            label='嘉宾简介'
            placeholder='请填写长文本，最多100字'
            showNumber
            maxnumber='100'
            maxLength={100}
            value={desc}
            onInputChange={this.onHandelChange.bind(this, 'desc')}
          />
        </View>
        <View className={`${prefix}-button`}>
          <MJButton
            text='确定'
            color='#DFE1E6'
            onButtonClick={this.saveClick.bind(this)}
            disabled={isClick}
          />
        </View>
      </View>
     
    )
  }
}

export default AddGuest
