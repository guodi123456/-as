import Taro, { Component } from '@tarojs/taro'
import { WebView } from '@tarojs/components'
import _ from 'lodash';

class webView extends Component {
  config = {
    navigationBarTitleText: '',
  }

  getUrl = () =>  {
    const { token, uid, ptid, activeId, id, type } = this.$router.params;
    let url = ''
    if (type === 'detail') {
       url = encodeURI(`http://acttest.mioji.com/act/#/detail/${activeId}/${token}/${uid}/${ptid}/${id}`)
    }
    return url
  }

  render () {
    const url = this.getUrl();
    const decodeUrl = decodeURI(url);
    const hasProtocol = _.startsWith(decodeUrl, 'http://') || _.startsWith(decodeUrl, 'https://');
    const webUrl = hasProtocol ? decodeUrl : `http://${decodeUrl}`;

    return (
      <WebView src={`${webUrl}#wechat_redirect`} />
    );
  }
}

export default webView;