import Taro, { Component } from '@tarojs/taro';
import { connect } from '@tarojs/redux';
import _ from 'lodash';
import { View } from '@tarojs/components';
import { getActiveLabels, getActiveAllLabels } from '../../actions/actives';
import { CardHeader, MJIcon, MJInput, MJSwitch, CheckBox } from '../../components'
import './index.scss';

let valList = [];
@connect(({ actives }) => ({
  activeAllLabels: _.get(actives, 'actives_Alllabels', {})
}), (dispatch) => ({
  onSetActiveLabels (data) {
    dispatch(getActiveLabels(data))
  },
  onGetActiveAllLabels (data) {
    dispatch(getActiveAllLabels(data))
  }
}))
class AddInformation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      defaultList: _.isPlainObject(props.activeAllLabels) ? [
        {
          key:'姓名',
          isCheck: true,
          prevType: true,
          ktype: 1,
          type: 1
        },
        {
          key:'手机号',
          isCheck: true,
          prevType: true,
          ktype: 2,
          type: 1
        },
        {
          key:'所在城市',
          isCheck: false,
          prevType: false,
          ktype: 7,
          type: 0
        },
        {
          key:'公司名称',
          isCheck: false,
          prevType: false,
          ktype: 3,
          type: 0
        },
        {
          key:'业务领域',
          isCheck: false,
          prevType: false,
          ktype: 6,
          type: 0
        },
        {
          key:'职位',
          isCheck: false,
          prevType: false,
          ktype: 4,
          type: 0
        },
        {
          key:'邮箱',
          isCheck: false,
          prevType: false,
          ktype: 5,
          type: 0
        }
      ] : props.activeAllLabels,
      addList: []
    }
  }
  static defaultProps = {
      prefix: 'add-information',
    }
    config = {
    navigationBarTitleText: '信息编辑',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  // 获取Switch状态
  onChangeSw = (type, index, check) => {
    const _list = this.state[type];
    _list[index].type = Number(check);
    this.setState({
      [type]: _list
    })
  }

  // 获取checkbox value
  changeClick = (index, value) => {
    const val = value.val;
    const _list = this.state.defaultList;
    _list[index].isCheck = Boolean(val);
    this.setState({
      defaultList: _list
    })
  }

  // 确认事件
  saveClick = () => {
    const [all_list, new_list] = this.setList();
    this.props.onSetActiveLabels({
      url: 'active_detail.enter_info.content',
      data: _.cloneDeep(new_list)
    });
    this.props.onGetActiveAllLabels(_.cloneDeep(all_list));
    valList = [];
    Taro.navigateBack({delta: 1})
  }

  setList = () => {
    const { defaultList, addList } = this.state;
    let all_list = [];
    let new_list = [];
    defaultList.forEach(item => {
      item.isCheck && new_list.push({
        key: item.key,
        ktype: item.ktype,
        type: item.type
      });
      all_list.push({
        ...item,
        prevType: item.isCheck
      })
    })
    addList.forEach((item, index) => {
      var _item = item;
      if(_.trim(valList[index])) {
        _item.key=valList[index];
        new_list.push({
          key: _item.key,
          ktype: _item.ktype,
          type: _item.type
        });
        all_list.push({
          ...item,
          prevType: item.isCheck
        })
      }
    })
    return [all_list, new_list]
  }

  // 获取input value
  getInputChange = (index, e) => {
    const val = e.target.value;
    valList[index] = val;
  }

  // 添加信息
  addInformation = () => {
    const add_list = this.state.addList;
    add_list.push({
      key:'',
      isCheck: true,
      prevType: false,
      ktype: -1,
      type: 0
    })
    this.setState({
      addList: add_list
    })
  }

  // 删除添加的信息
  deleteAddList = (index) => {
    const add_list = this.state.addList;
    add_list.splice(index, 1);
    valList.splice(index, 1);
    this.setState({
      addList: add_list
    })
  }

  render () {
    const { prefix='add-information' } = this.props;
    const { defaultList, addList } = this.state;
    return (
      <View className={prefix}>
        <CardHeader
          title='选择您需要的信息'
          color='#EB0911'
        ></CardHeader>
        {
          defaultList.length && defaultList.map((item,index)=>{
          const { key, type, isCheck, prevType } = item;
          return(
            <View className={`${prefix}-item`} key={index}>
                <View className={`${prefix}-item-left`}>
                  <CheckBox
                    disabled={prevType}
                    checked={index > 1 ? isCheck : true}
                    value={index}
                    onCheckChange={this.changeClick.bind(this, index)}
                  />
                <View className={`${prefix}-item-left-des`}>{key}</View>
                </View>
                {
                  index > 1 ? 
                  <View className={`${prefix}-item-right`}>
                    <View className={`${prefix}-item-right-required`}>{type ? '必填' : '非必填'}</View>
                    <MJSwitch
                      onChangeSw={this.onChangeSw.bind(this, 'defaultList', index)}
                      checked={type}
                    />
                  </View> : null
                }
            </View>
        )})}
        <View className={`${prefix}-title`}>
           <CardHeader
             title='自定义信息'
             color='#EB0911'
           />
        </View>
        <View className={`${prefix}-info`}>
          {
            addList.length && addList.map((item, index) => {
              return (
                <View key={index}>
                  <View className={`${prefix}-info-title`}>
                    <View className={`${prefix}-info-title-tip`}>
                        <View className={`${prefix}-info-title-tip-icon`}
                          onClick={this.deleteAddList.bind(this, index)}
                        >
                            <MJIcon type='hdlu_yichu' color='#EB0911' size={32} />
                        </View>
                        <View className={`${prefix}-info-title-tip-text`}>{`自定义信息 ${index + 1}`}</View>
                    </View>
                    <View className={`${prefix}-info-title-required`}>
                        <View className={`${prefix}-info-title-required-text`}></View>
                        <MJSwitch
                          onChangeSw={this.onChangeSw.bind(this, 'addList', index)}
                        />
                    </View>
                  </View>
                  <View className={`${prefix}-info-input`}>
                      <MJInput
                        placeholder='请填写自定义信息名称，最多50字'
                        maxLength={50}
                        value={valList[index]}
                        onInputChange={this.getInputChange.bind(this, index)}
                      />
                  </View>
                </View>
              )
            })
          }
          <View className={`${prefix}-info-add`}
            onClick={this.addInformation}
          >
            <View className={`${prefix}-info-add-icon`}>+</View>
            <View className={`${prefix}-info-add-text`}>继续添加</View>
          </View>
        </View>
        <View
          className={`${prefix}-button`}
          onClick={this.saveClick}
        >确定</View>
     </View>
    )
  }
}

export default AddInformation