import Taro, { Component } from '@tarojs/taro';
import { AtTabs, AtTabsPane } from 'taro-ui';
import { connect } from '@tarojs/redux';
import { View, Text, Button } from '@tarojs/components';
import _ from 'lodash';
import { MJSearch, MemberItem, PeopleList, CheckBox } from '../../components';
import { requestContactInfo } from "../../actions/actives";
import request from '../../utils/request'
import { replacePeopleList, searchPeopleList } from '../../utils'
import './index.scss';

const tabList = [{
  type: 0,
  title: '待审核',
}, {
  type: 1,
  title: '已通过',
}];

let inputVal = '';
@connect(({ actives }) => ({
  contactData: _.get(actives, 'contact_data', {})
  }), (dispatch) => ({
    onRequestContactInfo (query, flag) {
      dispatch(requestContactInfo(query, flag))
    }
  }))
class CheckList extends Component {
  constructor(props) {
    super(props);
    const params = _.get(this.$router, 'params', {});
    this.state = {
      checkedList: [],
      current: 0,
      active_id: params.active_id,
      state_tab: +params.activeType,
      searchList: [[],[]],
      flag: true
    }
  }



  static defaultProps = {
    prefix: 'contacts-info',
  }
  config = {
    navigationBarBackgroundColor: '#FAFAFA',
    navigationBarTitleText: '待审核名单'
  }

  componentWillMount() {
    // 获取审核名单信息
    this.getResquestInfo(0, true);
  }

  componentDidShow = () => {
    this.interval = setInterval(() => {}, 5000)
  }

  componentWillUnmount = () => {
    clearInterval(this.interval);
  }
  componentDidHide = () => {
    clearInterval(this.interval);
  }

  getResquestInfo = (mode, flag) => {
    this.props.onRequestContactInfo({
      id: this.state.active_id,
      mode,
      status: this.state.state_tab,
      filter: {key: ''}
    }, flag)
  }

  // 切换tab
  handleClick (value) {
    let _flag = value === 0 ? true : false;
    this.setState({
      current: value,
      flag: _flag,
      searchList: [[],[]],
      isSearch: false,
    })
    this.getResquestInfo(value, _flag);
    if (this.interval) {
      clearInterval(this.interval);
    }
    this.interval = setInterval(() => this.getResquestInfo(value, _flag), 60000)
  }

  // 搜集子组件的选中状态
  handleChange = (value) => {
    const val = value.val;
    const { checkedList } = this.state;
    let list = checkedList;
    if (!val) {
      const uid = value.uid;
      const idx = checkedList.findIndex((item) => {
        return uid === item
      })
      list.splice(idx, 1);
      this.setState({
        checkedList: list
      })
      return;
    }
    list.push(val);
    this.setState({
      checkedList: list
    })
    
  }

  // 全选
  onHandleChange = (people_list, value) => {
    const val = value.val;
    if (val) {
      let list = _.flatten(people_list).map(item => {
        return item.csuid;
      })
      this.setState({
        checkedList: list
      })
      return;
    }
    this.setState({
      checkedList: []
    })
  }
  // 点击button事件
  aklsnCLick = async () => {
    let timer;
    const { checkedList, active_id } = this.state;
    const res = await request({
      type: 'api45712',
      query: {
        id: active_id,
        csuids: checkedList
      }
    })
    if(res.statusCode === 200) {
      Taro.showToast({
        title: `本次审核通过${checkedList.length}人`,
        icon: 'success'
      })
      this.setState({
        checkedList: []
      })
      timer = setTimeout(() => {
        this.getResquestInfo(0, true);
        timer = null;
      }, 500)
    } else {
      Taro.showToast({
        title: '操作失败，请重试',
        icon: 'none',
      })
    }
    
  }
  
  // 获取搜索框value 
  getSearchCont = (val) => {
    inputVal = val;
    if (!val.trim()) {
      this.setState({
        isSearch: false
      })
    }
  }
  // 搜索查询
  seachClick = async (mode) => {
    if(!inputVal.trim()) {
      return;
    }
    const { active_id, state_tab } = this.state;
    const res = await searchPeopleList(active_id, mode, inputVal, +state_tab);
    const data = res.data.data
    if(mode === 0) {
      data.list = replacePeopleList(data.list)
    }
    this.setState({
      searchList: data.list,
      isSearch: true
    })
  }

  render () {
    const { prefix='contacts-info', contactData=[] } = this.props;
    const { checkedList, flag, searchList, isSearch, active_id } = this.state;
    let list = isSearch ? searchList : contactData;
    
    const type0Len = list[0] && list[0].length;
    const type1Len = list[1] && list[1].length;
    return (
      <View className={prefix}>
        <View
          className={`${prefix}-tab`}
        >
          <AtTabs
            current={this.state.current}
            tabList={tabList}
            onClick={this.handleClick.bind(this)}
            tabDirection='horizontal'
            animated={false}
            className={`${prefix}-tab`}
          >
            <AtTabsPane current={this.state.current} index={0} >
              <View className={`${prefix}-tab-content`}>
              {
                flag ? 
                <View>
                  <View className={`${prefix}-tab-content-search`}>
                    <MJSearch
                      placeholder='按姓名、手机号、公司名称搜索'
                      type='text'
                      value=''
                      maxLength={25}
                      onInputChange={this.getSearchCont.bind(this)}
                      onInputClick={this.seachClick.bind(this, 0)}
                    />
                  </View>
                  <View
                    className={`${prefix}-tab-content-checkAll`}
                  >
                    <View className={`${prefix}-tab-content-checkAll-checkbox`}>
                      <CheckBox
                        value='all'
                        onCheckChange={this.onHandleChange.bind(this, list)}
                        checked={checkedList.length !== 0 ? checkedList.length === type0Len + type1Len : false}
                      />
                    </View>
                    <Text className={`${prefix}-tab-content-checkAll-title`}>选择全部（共{type0Len + type1Len ? type0Len + type1Len : 0}人）</Text>
                  </View>
                <View className={`${prefix}-tab-content-newPerson`}>
                  {
                    type0Len || type1Len ? (
                      <View className={`${prefix}-tab-content-newPerson-list`}>
                        <View className={`${prefix}-tab-content-newPerson-title`}></View>
                        {
                          list[0].map((item, index) => {
                            const { csuid, content } = item;                       
                            return (                                  
                              <MemberItem
                                key={index}
                                show={1}
                                data={content}
                                activeId={active_id}
                                checked={checkedList.length === type0Len + type1Len || checkedList.includes(csuid) ? true : false}
                                value={csuid}
                                onHandleCange={this.handleChange.bind(this)}
                              />
                            )
                          })
                        }
                        {
                          (type0Len && type1Len) ?
                          <View className={`${prefix}-tab-content-newPerson-screen`}>
                            <View className={`${prefix}-tab-content-newPerson-screen-br`}></View>
                            <Text className='font24'>以下为更早查看</Text>
                            <View className={`${prefix}-tab-content-newPerson-screen-br`}></View>
                          </View> : null
                        }
                        {
                          list[1].map((item, index) => {
                            const { csuid, content } = item;
                            return (                                  
                              <MemberItem
                                key={index}
                                show={1}
                                data={content}
                                activeId={active_id}
                                checked={checkedList.length === type0Len + type1Len || checkedList.includes(csuid) ? true : false}
                                value={csuid}
                                onHandleCange={this.handleChange.bind(this)}
                                onToClick={this.navigatoDetai.bind(this)}
                              />
                            )
                          })
                        }
                      </View>
                    ) : (
                      <View className={`${prefix}-tab-none`}>{isSearch ? '未找到相关信息' : '暂时无人报名'}</View>
                    )
                  }
                </View>
                </View> : null 
              }
              </View>
            </AtTabsPane>
            <AtTabsPane current={this.state.current} index={1}>
              <View className={`${prefix}-tab-contsub`}>
                {
                  !flag ?
                  <PeopleList
                    people_list={list}
                    num={list.length}
                    title='已通过'
                    isSearched={isSearch}
                    activeId={active_id}
                    onInputChange={this.getSearchCont.bind(this)}
                    onInputClick={this.seachClick.bind(this, 1)}
                  /> : null
                }
              </View>
            </AtTabsPane>
          </AtTabs>
        </View>
        {
          this.state.current === 0 ? <View className={`${prefix}-tab-content-button`}>
          <Button
            onClick={this.aklsnCLick}
            className={`${prefix}-tab-content-button-item`}
            disabled={checkedList.length === 0}
          >
            审核通过
          </Button>
        </View> : null
        } 
      </View>
    )
  }
}

export default CheckList