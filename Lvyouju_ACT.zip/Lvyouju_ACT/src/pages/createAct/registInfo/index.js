import Taro, { Component, navigateTo } from '@tarojs/taro';
import { View, Text, Button} from '@tarojs/components';
import _ from 'lodash';
import { connect } from '@tarojs/redux';
import { MJIcon, MJSwitch, CardHeader, AddButton } from '../../../components';
import { getActiveLabels, getActiveAllLabels } from '../../../actions/actives';
import navigate from '../../../utils/navigate'
import './index.scss';

@connect(({ actives }) => ({
  activeLabels: _.get(actives, 'active_detail.enter_info.content', {}),
  activeAllLabels: _.get(actives, 'actives_Alllabels', {}),
  isVerify: _.get(actives, 'active_detail.enter_info.is_verify', {}),
}), (dispatch) => ({
  onSetActiveLabels (data) {
    dispatch(getActiveLabels(data))
  },
  onGetActiveAllLabels (data) {
    dispatch(getActiveAllLabels(data))
  }
}))
class RegistInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      infoList: [
        {key: '姓名', ktype: 1, type: 1},
        {key: '手机号', ktype: 2, type: 1},     
      ],
    }
  }
    static defaultProps = {
      prefix: 'regist-info',
    }
    config = {
    navigationBarTitleText: '新建活动',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  onAddCustom = () => {
    navigate({
      page: 'addInformation'
    })
  }

  deleteLabels = (index) => {
    if (index > 1) {
      const { activeLabels, activeAllLabels } = this.props;
      const new_list = _.cloneDeep(activeLabels);
      const all_list = _.cloneDeep(activeAllLabels);
      activeAllLabels.forEach((item, i) => {
        if(item.ktype === new_list[index].ktype) {        
          all_list[i].type = false;
          all_list[i].isCheck = all_list[i].prevType = false;
        }
      })
      new_list.splice(index, 1);
      this.props.onSetActiveLabels({
        url: 'active_detail.enter_info.content',
        data: new_list
      });
      this.props.onGetActiveAllLabels(all_list);
    }
  }

  onCheckChange = (val) => {
    this.check = val;
  }

  nextButton = () => {
    const { onNextButton } = this.props;
    onNextButton(this.check);
  }

  render () {
    const { prefix='regist-info', onPreButton, activeLabels, isVerify=true } = this.props;
    const { infoList } = this.state;
    const list = _.isPlainObject(activeLabels) ? infoList : activeLabels;
    
    return (
      <View className={prefix}>
        <View className={`${prefix}-base`}>
          <View className={`${prefix}-base-title`}>
            <CardHeader
              title='基础信息'
              color='#EB0911'
            ></CardHeader>
          </View>
          {
            list.length ? list.map((item, index) => (
              <View className={`${prefix}-base-edit`} key={index}>
                <MJIcon
                  type='hdlu_yichu'
                  size={36}
                  color={index < 2 ? 'rgba(201,206,214,1)' : 'rgba(235,9,17,1)'}
                  onClick={this.deleteLabels.bind(this, index)}
                />
                <Text className={`${prefix}-base-edit-title`}>{ item.key }</Text>
                {item.type ? <Text className={`${prefix}-base-edit-require`}>*</Text> : null}
              </View>
            )) : null
          }
          <View
            className={`${prefix}-base-add flex-cent font24`}
          >
            <AddButton
              title='添加信息'
              type='normal'
              color='#EB0911'
              onAddActive={this.onAddCustom.bind(this)}
            />
          </View>
        </View>
        <View className={`${prefix}-check`}>
          <View className={`${prefix}-check-title`}>
            <CardHeader
              title='信息审核'
              color='#EB0911'
            ></CardHeader>
          </View>
          <View className={`${prefix}-check-botcont`}>
            <Text className={`${prefix}-check-botcont-left`}>报名后需审核</Text>
            <View className={`${prefix}-check-botcont-right`}>
              <Text className={`${prefix}-check-botcont-right-text`}>必填</Text>
              <MJSwitch
                checked={isVerify}
                onChangeSw={this.onCheckChange.bind(this)}
              />
            </View>
          </View>
          <View className={`${prefix}-check-buttons`}>
            <Button className={`${prefix}-check-buttons-item`} onClick={onPreButton}>
              上一步
            </Button>
            <Button
              className={`${prefix}-check-buttons-item`}
              onClick={this.nextButton}
            >
              下一步
            </Button>
          </View>
        </View>
      </View>
    )
  }
}

export default RegistInfo
