import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
// import _ from 'lodash';
import { MJIcon } from '../../../../components';
import './index.scss';

// @connect(({ counter }) => ({
//   counter
// }), (dispatch) => ({
//   doLogin (query) {
//     dispatch(doLogin(query))
//   },
// }))
class Steps extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }
    static defaultProps = {
      prefix: 'create-actives',
      stepList: []
    }
    config = {
    navigationBarTitleText: '创建活动',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  componentWillReceiveProps () {
  }

  componentWillMount () {
  }

  componentDidShow () {
   }

  componentDidHide () { }

  // 获取当前的itemClass
  getCurItem = (curType) => {
    let curItem = '';
    if (curType === 0) {
      curItem = 'firstItem'
    } else if (curType === 1) {
      curItem = 'secondItem'
    } else if (curType === 2) {
      curItem = 'lastItem'
    }
    return curItem;
  }



  render () {
    const { prefix='create-actives', stepList, curType } = this.props;
    const curItem = this.getCurItem(curType)
    return (
      <View className={prefix}>
        {
          stepList.map((item, index) => {
            const { id, text, status } = item;
            return (
              <View
                className={`${prefix}-item ${curType === id ? curItem : ''} ${status ? 'finishItem' : ''}`}
                key={index}
              >
                <View className={`${prefix}-item-icon`}>
                  {
                    !status ? (
                      <View className={`${prefix}-item-icon-circle ${curType === id ? 'curCircle' : ''}`}>{index + 1}</View>
                    ) : (
                      <View>
                        <MJIcon
                          type='hdlu_yiwancheng'
                          size={40}
                          color='#FFFFFF'
                        />
                      </View>
                    )
                  }
                  </View>
                <View className={`${prefix}-item-text`}>{text}</View>
                {
                  index !== 2 ? (
                    <View className={`${prefix}-item-arrow`}>
                      <MJIcon
                        type='hdlu_xiayibu'
                        size={48}
                        color='#FFFFFF'
                      />
                    </View>
                  ) : null
                }
              </View>
            )
          })
        }
      </View>
    )
  }
}
export default Steps
