import Taro, { Component } from '@tarojs/taro';
import { connect } from '@tarojs/redux';
import { View, Picker, Input, Image, Textarea } from '@tarojs/components';
import _ from 'lodash';
import moment from 'moment';
import { CardHeader, MJIcon, UploadImage, AddButton, MJButton, ActiveProcess, FloatLayout } from '../../components';
import dateFormater from '../../utils/formatDate';
import Steps from "./activeInfo/steps";
import RegistInfo from "./registInfo";
import {
  getInitDetail,
  requestActiveDetail,
  handelChangeActiveDetailData,
  saveActive,
  getActiveLabels,
} from '../../actions/actives';
import './index.scss';
import navigate from '../../utils/navigate';


@connect(({ actives, auth }) => ({
  activeDetail: _.get(actives, 'active_detail', {}),
  id: _.get(actives, 'active_detail.id', ''),
  token : _.get(auth, 'token', ''),
  ptid : _.get(auth, 'agency_info.ptid', ''),
  uid : _.get(auth, 'uid', ''),
}), (dispatch) => ({
  onInitActiveDetail () {
    dispatch(getInitDetail())
  },
  onRequestActiveDetail (query) {
    dispatch(requestActiveDetail(query))
  },
  onHandelChangeActiveDetailData(data) {
    dispatch(handelChangeActiveDetailData(data))
  },
  onSetActiveLabels (data) {
    dispatch(getActiveLabels(data))
  },
  onSaveActive (data) {
    dispatch(saveActive(data))
  },
}))

class CreateAct extends Component {
  constructor(props) {
    super(props);
    this.state = {
      stepList: [
        {
          text: '活动信息',
          id: 0,
          status: false
        },
        {
          text: '报名信息',
          id: 1,
          status: false
        },
        {
          text: '预览发布',
          id: 2,
          status: false
        }
      ],
      curType: 0,
      moduleOpen: false,
      flowOpen: false,
      openIndex: 0,
    }
  }
    static defaultProps = {
      prefix: 'create-actives',
    }
    config = {
    navigationBarTitleText: '创建活动',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  componentWillReceiveProps () {
  }

  componentWillMount () {
  }

  componentDidShow () {
   }

  componentDidHide () { }

  componentDidMount () {
    const activeId = _.get(this.$router, 'params.activeId', '');
    const type = _.get(this.$router, 'params.type', '');
    if (type === 'edit') {
      this.props.onRequestActiveDetail({id: activeId});
    } else {
      this.props.onInitActiveDetail();
    }
  }

  // 下一步
  onNextButton = (i, check=true) => {
    const { activeDetail, id, token, uid, ptid } = this.props;
    console.log('token:', token, 'id:', id,'uid:', uid, 'ptid:', ptid, 'activeDetail:', activeDetail)
    const curStepList = this.state.stepList;
      curStepList[i].status= !this.state.stepList[i].status;
      if (i < 1) {
        this.setState({
          curType: i + 1,
          stepList: curStepList
        })
      } else {
        this.props.onSetActiveLabels({
          url: 'active_detail.enter_info.is_verify',
          data: Number(check)
        })
        navigate({
          page : 'webView',
          param: {
            id: 1,
            type: 'detail',
            token,
            uid,
            ptid,
            activeId: id
          },
        });
      }
    this.props.onSaveActive({ ...activeDetail, id});  
  }
  // 上一步
  onPreButton = (i) => {
    const curStepList = this.state.stepList;
      curStepList[i - 1].status= !this.state.stepList[i - 1].status;
      if (i > 0) {
        this.setState({
          curType: i - 1,
          stepList: curStepList
        })
      }
  } 

  // 选择地点
  onFocus = () => {
    const { id } = this.props;
    navigate({
      page: 'choiceLocation',
      param: {
        id,
      }
    })
  }

  // 更改详情基本信息内容
  changeBaseInfoData = (option, e) => {
    const activeId = _.get(this.$router, 'params.activeId', '');
    const { activeDetail, id } = this.props;
    const num = _.get(activeDetail, 'num', 0);
    if (
      (option === 'start_date' || option === 'end_date' || option === 'name' ||
      option === 'start_time' || option === 'end_date') && activeId
      ) {
        Taro.showModal({
          confirmText: '确认编辑',
          cancelText: '取消',
          cancelColor: '#272C33',
          confirmColor: '#0061F3',
          content: `当前已有${num}人报名，修改时间或地点后，请及时告知用户`,
          success: ({ confirm, cancel }) => {
            if (confirm) {
              const value = option === 'img' ? e : e.target.value;
              const path = String('active_detail.base_info.'.concat(option));
              this.props.onHandelChangeActiveDetailData({
                path,
                value
              });
            } else if (cancel) {
            }
          }
        })
      }
    const value = option === 'img' ? e : e.target.value;
    const path = String('active_detail.base_info.'.concat(option));
    this.props.onHandelChangeActiveDetailData({
      path,
      value
    });
    if(option !== 'sponsor' && option !== 'remind' && option !== 'desc' && option !== 'title') {
      this.props.onSaveActive({ ...activeDetail, id})
    }
  }

  // 新增流程
  onAddProcess = (index, date) => {
    navigate({
        page: 'addProcess',
        param: {
          flow_index: index,
          type: 'add',
          date,
        }
    })
  }

  // 编辑flow
  editFlow = (index, idx) => {
    navigate({
      page: 'addProcess',
      param: {
        flow_index: index,
        list_index: idx,
        type: 'edit'
      }
    })
  }

  // 删除flow
  deleteFlow = (index, idx) => {
    const { activeDetail, id } = this.props;
    const list = _.get(activeDetail, `flow.${index}.list`)
    const flow = _.get(activeDetail, 'flow')
    list.splice(idx, 1);
    if(list.length === 0) {
      flow.splice(index, 1);
      this.props.onHandelChangeActiveDetailData({
        path: 'active_detail.flow',
        value: flow
      });
    }
    this.props.onHandelChangeActiveDetailData({
      path: `active_detail.flow.${index}.list`,
      value: list
    });
    this.props.onSaveActive({ ...activeDetail, id});
  }

  // 调整顺序
  onChangeIsOpen = (index, option) => {
    const { activeDetail, id } = this.props;
    const { flowOpen, moduleOpen } = this.state;
    if(option === 'moduleOpen') {
      this.setState({
        moduleOpen: !moduleOpen,
        openIndex: index,
      })
    } else {
      this.setState({
        flowOpen: !flowOpen,
        openIndex: index,
      })
    }
    this.props.onSaveActive({ ...activeDetail, id});
  }

  // 关闭调序
  onHandleClose = (option) => {
    const { flowOpen, moduleOpen } = this.state;
    if(option === 'moduleOpen') {
      this.setState({
        moduleOpen: !moduleOpen,
      })
    } else {
      this.setState({
        flowOpen: !flowOpen,
      })
    }
    
  }

  //上移
  onMoveUp = (option, flowIndex, listIndex) => {
    const { activeDetail } = this.props;
    const list = _.get(activeDetail, `${option}.${flowIndex}.list`);
    if (listIndex !== 0) {
      let temp = list[listIndex - 1];
      list[listIndex - 1] = list[listIndex];
      list[listIndex] = temp;
    } else {
      list.push(list.shift());
    }
    this.props.onHandelChangeActiveDetailData({
      path: `active_detail.${option}.${flowIndex}.list`,
      value: list
    });

  }
  //下移
  onMoveDown = (option, flowIndex, listIndex) => {
    const { activeDetail } = this.props;
    const list = _.get(activeDetail, `${option}.${flowIndex}.list`);
    if(listIndex!=list.length-1){
      let temp = list[listIndex + 1];
      list[listIndex + 1] = list[listIndex];
      list[listIndex] = temp;
    } else{
      list.unshift( list.splice(listIndex,1)[0]);
    }
    this.props.onHandelChangeActiveDetailData({
      path: `active_detail.${option}.${flowIndex}.list`,
      value: list
    });
  }

  // 新增模块
  onAddCustom = () => {
    navigate({
      page: 'addCustom'
    })
  }
  // 删除模块
  handelDeleteModule = (index) => {
    const { activeDetail, id } = this.props;
    const module = _.get(activeDetail, 'module');
    module.splice(index, 1);
    Taro.showModal({
      confirmText: '删除',
      cancelText: '取消',
      cancelColor: '#272C33',
      confirmColor: '#EB0911',
      content: '确定要删除该模块吗？',
      success: ({ confirm, cancel }) => {
        if (confirm) {
          this.props.onHandelChangeActiveDetailData({
            path: `active_detail.module`,
            value: module
          });
        } else if (cancel) {
        }
      }
    })
    this.props.onSaveActive({ ...activeDetail, id});
  }

  //模块添加内容
  handelEditModal = (moduleIndex, moduleType, type) => {
    const page = moduleType === 0 ? 'addGuest' : moduleType === 1 ? 'addContacts' : 'customPicText';
    navigate({
      page,
      param: {
        moduleIndex,
        moduleType,
        type
      }
    })
  }
  // 编辑模块
  editModule = (index, idx) => {
    const { activeDetail } = this.props;
    const moduleType = _.get(activeDetail, `module.${index}.module_type`);
    const page = moduleType === 0 ? 'addGuest' : moduleType === 1 ? 'addContacts' : 'customPicText';
    navigate({
      page,
      param: {
        moduleIndex: index,
        listIndex: idx,
        moduleType,
        type: 'edit'
      }
    })
  }

  // 删除模块的一条信息
  deleteModule = (index, idx) => {
    const { activeDetail, id } = this.props;
    const list = _.get(activeDetail, `module.${index}.list`)
    list.splice(idx, 1)
    this.props.onHandelChangeActiveDetailData({
      path: `active_detail.module.${index}.list`,
      value: list
    });
    this.props.onSaveActive({ ...activeDetail, id});
  }





  render () {
    const { prefix='create-actives', activeDetail = {} } = this.props;
    const { base_info = {}, flow = [], module = [] } = activeDetail;
    const {
      img = '',
      title = '',
      start_date = '',
      start_time = '',
      end_date = '',
      end_time = '',
      sponsor = '',
      entered_date = '',
      remind = '',
      desc = '',
      address = {}
    } = base_info;
    const { name } = address;
    const { stepList, curType, moduleOpen, flowOpen, openIndex } = this.state;
    const isClick = !img || !title || !start_date || !start_time || !end_date || !end_time || !sponsor || !name;
    return (
      <View className={prefix}>
        <View className={`${prefix}-step`}>
          <Steps
            stepList={stepList}
            curType={curType}
          ></Steps>
        </View>
        {
          curType === 0 ? (
            <View className={`${prefix}-info`}>
              <View className={`${prefix}-info-base`}>
                <CardHeader
                  title='基本信息'
                  color='#EB0911'
                ></CardHeader>
                <View className={`${prefix}-info-base-active`}>
                  <View className={`${prefix}-info-base-active-label`}>
                    <View className={`${prefix}-info-base-active-label-text`}>活动图片</View>
                    <View className={`${prefix}-info-base-active-label-required`}>*</View>
                  </View>
                  <View className={`${prefix}-info-base-active-img`}>
                    <UploadImage
                      desc={1}
                      title='上传图片'
                      img={img}
                      onChangeImage={this.changeBaseInfoData.bind(this, 'img')}
                    >
                    </UploadImage>
                  </View>
                </View>
                <View className={`${prefix}-info-base-item`}>
                  <View className={`${prefix}-info-base-item-label`}>
                    <View className={`${prefix}-info-base-item-label-text`}>活动名称</View>
                    <View className={`${prefix}-info-base-item-label-required`}>*</View>
                  </View>
                  <View className={`${prefix}-info-base-item-content`}>
                    <Textarea
                      className={`${prefix}-info-base-item-content-textarea`}
                      placeholder='请填写活动名称'
                      autoHeight
                      onInput={this.changeBaseInfoData.bind(this, 'title')}
                      value={title}
                      placeholderClass={`${prefix}-info-base-item-content-placeholder`}
                    >
                    </Textarea>
                  </View>
                </View>
                <View className={`${prefix}-info-base-item`}>
                  <View className={`${prefix}-info-base-item-label labelDate`}>
                    <View className={`${prefix}-info-base-item-label-text`}>开始日期</View>
                    <View className={`${prefix}-info-base-item-label-required`}>*</View>
                  </View>
                  <View className={`${prefix}-info-base-item-content`}>
                    <View className={`${prefix}-info-base-item-content-date`}>
                      <Picker
                        mode='date'
                        start={moment().format('YYYY-MM-DD')}
                        end={moment().add(3, 'years').format('YYYY-MM-DD')}
                        onChange={this.changeBaseInfoData.bind(this, 'start_date')}
                      >
                        <View className={`${prefix}-info-base-item-content-date-picker ${start_date ? 'dateColor' : 'noDateColor'}`}>
                          {start_date ? dateFormater(start_date, ['年', '月', '日'], true, true) : '请选择日期'}
                        </View>
                      </Picker>
                      <View className={`${prefix}-info-base-item-content-date-icon`}>
                        <MJIcon
                          type='hdlu_zhankai'
                          color='#EB0911'
                          size={40}
                        >

                        </MJIcon>
                      </View>
                    </View>
                    <View className={`${prefix}-info-base-item-content-time`}>
                      <Picker
                        mode='time'
                        onChange={this.changeBaseInfoData.bind(this, 'start_time')}
                      >
                        <View className={`${prefix}-info-base-item-content-time-picker ${start_time ? 'timeColor' : 'noTimeColor'}`}>
                          <View className={`${prefix}-info-base-item-content-time-picker-text`}>时间</View>
                            {start_time || '-- : --'}
                        </View>
                      </Picker>
                      <View className={`${prefix}-info-base-item-content-time-icon`}>
                        <MJIcon
                          type='hdlu_zhankai'
                          color='#EB0911'
                          size={40}
                        >

                        </MJIcon>
                      </View>
                    </View>
                  </View>
                </View>
                <View className={`${prefix}-info-base-item`}>
                  <View className={`${prefix}-info-base-item-label labelDate`}>
                    <View className={`${prefix}-info-base-item-label-text`}>结束日期</View>
                    <View className={`${prefix}-info-base-item-label-required`}>*</View>
                  </View>
                  <View className={`${prefix}-info-base-item-content`}>
                    <View className={`${prefix}-info-base-item-content-date`}>
                      <Picker
                        mode='date'
                        start={moment().format('YYYY-MM-DD')}
                        end={moment().add(3, 'years').format('YYYY-MM-DD')}
                        onChange={this.changeBaseInfoData.bind(this, 'end_date')}
                      >
                        <View className={`${prefix}-info-base-item-content-date-picker ${end_date ? 'dateColor' : 'noDateColor'}`}>
                        {end_date ? dateFormater(end_date, ['年', '月', '日'], true, true) : '请选择日期'}
                        </View>
                      </Picker>
                      <View className={`${prefix}-info-base-item-content-date-icon`}>
                        <MJIcon
                          type='hdlu_zhankai'
                          color='#EB0911'
                          size={40}
                        >
                        </MJIcon>
                      </View>
                    </View>
                    <View className={`${prefix}-info-base-item-content-time`}>
                      <Picker
                        mode='time'
                        onChange={this.changeBaseInfoData.bind(this, 'end_time')}
                      >
                        <View className={`${prefix}-info-base-item-content-time-picker ${end_time ? 'timeColor' : 'noTimeColor'}`}>
                          <View className={`${prefix}-info-base-item-content-time-picker-text`}>时间</View>
                            {end_time || '-- : --'}
                          </View>
                      </Picker>
                      <View className={`${prefix}-info-base-item-content-time-icon`}>
                        <MJIcon
                          type='hdlu_zhankai'
                          color='#EB0911'
                          size={40}
                        >

                        </MJIcon>
                      </View>
                    </View>
                  </View>
                </View>
                <View className={`${prefix}-info-base-item`}>
                  <View className={`${prefix}-info-base-item-label labelDate`}>
                    <View className={`${prefix}-info-base-item-label-text`}>活动地点</View>
                    <View className={`${prefix}-info-base-item-label-required`}>*</View>
                  </View>
                  <View className={`${prefix}-info-base-item-content`}>
                    <View className={`${prefix}-info-base-item-content-nameInput`} onClick={this.onFocus.bind(this)}>
                      <Input
                        value={name}
                        option='name'
                        onInput={this.changeBaseInfoData.bind(this, 'name')}
                        className={`${prefix}-info-base-item-content-input-content`}
                        placeholder='请选择活动地点'
                        placeholderClass={`${prefix}-info-base-item-content-input-placeholder`}
                      ></Input>
                    </View>
                    <View className={`${prefix}-info-base-item-content-icon`}>
                      <MJIcon
                        type='hdlu_zuobiao'
                        color='#EB0911'
                        size={40}
                      >
                      </MJIcon>
                    </View>
                  </View>
                </View>
                <View className={`${prefix}-info-base-item`}>
                  <View className={`${prefix}-info-base-item-label host`}>
                    <View className={`${prefix}-info-base-item-label-text`}>主办方</View>
                    <View className={`${prefix}-info-base-item-label-required`}>*</View>
                  </View>
                  <View className={`${prefix}-info-base-item-content`}>
                    <Textarea
                      placeholder='请填写主办方，最多10个字'
                      className={`${prefix}-info-base-item-content-textarea`}
                      autoHeight
                      onInput={this.changeBaseInfoData.bind(this, 'sponsor')}
                      value={sponsor}
                      maxlength={10}
                      placeholderClass={`${prefix}-info-base-item-content-placeholder`}
                    >
                    </Textarea>
                  </View>
                </View>
                <View className={`${prefix}-info-base-item`}>
                  <View className={`${prefix}-info-base-item-label labelDate`}>
                    <View className={`${prefix}-info-base-item-label-text`}>报名截止</View>
                    <View className={`${prefix}-info-base-item-label-required`}></View>
                  </View>
                  <View className={`${prefix}-info-base-item-content`}>
                  <View className={`${prefix}-info-base-item-content-end`}>
                      <Picker
                        mode='date'
                        start={moment().format('YYYY-MM-DD')}
                        end={moment().add(3, 'years').format('YYYY-MM-DD')}
                        onChange={this.changeBaseInfoData.bind(this, 'entered_date')}
                      >
                        <View className={`${prefix}-info-base-item-content-end-picker ${entered_date ? 'dateColor' : 'noDateColor'}`}>
                          {entered_date ? dateFormater(entered_date, ['年', '月', '日']) : '请选择日期'}
                        </View>
                      </Picker>
                      <View className={`${prefix}-info-base-item-content-end-icon`}>
                        <MJIcon
                          type='hdlu_zhankai'
                          color='#EB0911'
                          size={40}
                        >
                        </MJIcon>
                      </View>
                    </View>
                  </View>
                </View>
                <View className={`${prefix}-info-base-item`}>
                  <View className={`${prefix}-info-base-item-label`}>
                    <View className={`${prefix}-info-base-item-label-text`}>特别提醒</View>
                    <View className={`${prefix}-info-base-item-label-required`}></View>
                  </View>
                  <View className={`${prefix}-info-base-item-content`}>
                    <Textarea
                      placeholder='请填写特殊提醒，最多100字'
                      className={`${prefix}-info-base-item-content-textarea`}
                      autoHeight
                      onInput={this.changeBaseInfoData.bind(this, 'remind')}
                      value={remind}
                      maxlength={100}
                      placeholderClass={`${prefix}-info-base-item-content-placeholder`}
                    >
                    </Textarea>
                    <View className={`${prefix}-info-base-item-content-number`}>
                      {remind.length}/100
                    </View>
                  </View>
                </View>
                <View className={`${prefix}-info-base-item desc`}>
                  <View className={`${prefix}-info-base-item-label`}>
                    <View className={`${prefix}-info-base-item-label-text`}>活动简介</View>
                    <View className={`${prefix}-info-base-item-label-required`}></View>
                  </View>
                  <View className={`${prefix}-info-base-item-content`}>
                    <Textarea
                      placeholder='请填写活动简介，最多500字'
                      className={`${prefix}-info-base-item-content-textarea`}
                      autoHeight
                      onInput={this.changeBaseInfoData.bind(this, 'desc')}
                      value={desc}
                      maxlength={500}
                      placeholderClass={`${prefix}-info-base-item-content-placeholder`}
                    >
                    </Textarea>
                    <View className={`${prefix}-info-base-item-content-number`}>
                      {desc.length}/500
                    </View>
                  </View>
                </View>
              </View>
              <View className={`${prefix}-info-process`}>
                <View className={`${prefix}-info-process-title`}>
                  <CardHeader
                    title='活动流程'
                    color='#EB0911'
                  ></CardHeader>
                </View>
                {
                  flow && flow.length > 0 ? (
                    <View className={`${prefix}-info-process-content`}>
                      {
                        flow.map((flowItem, index) => {
                          const { date, list = [] } = flowItem;
                          return (
                            <View className={`${prefix}-info-process-content-flow`} key={index}>
                              {
                                flow.length > 1 ? (
                                  <View className={`${prefix}-info-process-content-flow-date`}>
                                    {dateFormater(date, ['年', '月', '日'], true, true)}
                                  </View>
                                ) : null
                              }
                              {
                                list && list.length > 0 ? (
                                  list.map((item, idx) => {
                                    const { start_time: startTime, end_time: endTime, define, title: flowTitle } = item;
                                    const pointNum = idx + 1;
                                    return (
                                      <ActiveProcess
                                        key={idx}
                                        pointNum={pointNum}
                                        startTime={startTime}
                                        endTime={endTime}
                                        subContent={define}
                                        content={flowTitle}
                                        iconType={0}
                                        onLeftIconClick={this.editFlow.bind(this, index, idx)}
                                        onRightIconClick={this.deleteFlow.bind(this, index, idx)}
                                      >
                                      </ActiveProcess>
                                    )
                                  })
                                ) : null 
                              }
                              {
                                list && list.length > 0 ? (
                                  <View className={`${prefix}-info-process-content-flow-btns`}>
                                      <View className={`${prefix}-info-process-content-flow-btns-add`}>
                                      <AddButton
                                        title='新增流程'
                                        type='normal'
                                        color='#EB0911'
                                        onAddActive={this.onAddProcess.bind(this, index, date)}
                                      />
                                    </View>
                                    <View className={`${prefix}-info-process-content-flow-btns-change`}>
                                      <AddButton
                                        title='调整顺序'
                                        type='normal'
                                        color='#EB0911'
                                        iconType='hdlu_diaohuan'
                                        onAddActive={this.onChangeIsOpen.bind(this, index, 'flowOpen')}
                                      />
                                    </View>
                                  </View>
                                ) : null
                              }
                            </View>
                          )
                        })
                      }
                      
                    </View>
                  ) : null
                }
                {
                  flow.length === 0 || flow[0].list.length === 0 ? (
                    <View className={`${prefix}-info-process-btn`}>
                      <AddButton
                        title='新增流程'
                        type='normal'
                        color='#EB0911'
                        onAddActive={this.onAddProcess.bind(this, 0, start_date)}
                      />
                    </View>
                  ) : null
                }
                {
                  flowOpen ? (
                    <FloatLayout
                      data={flow}
                      option='flow'
                      isOpened={flowOpen}
                      openIndex={openIndex}
                      onClose={this.onHandleClose.bind(this, 'flowOpen')}
                      onLeftIconClick={this.onMoveDown.bind(this, 'flow')}
                      onRightIconClick={this.onMoveUp.bind(this, 'flow')}
                    >
                    </FloatLayout>
                  ) : null
                }
              </View>
                {
                  module && module.length > 0 ? (
                    <View className={`${prefix}-info-custom`}>
                      {
                        module.map((item, index) => {
                          const { list: moduleList = [] , module_type: moduleType , title: moduleTitle } = item;
                          return(
                            <View className={`${prefix}-info-custom-content`} key={index}>
                              <View lassName={`${prefix}-info-custom-content-title`}>
                                <CardHeader
                                  title={moduleTitle}
                                  color='#EB0911'
                                ></CardHeader>
                              </View>
                                {
                                  moduleList && moduleList.length > 0 && moduleType === 0 ? (
                                    moduleList.map((moduleItem, idx) => {
                                      const { img: moduleImg, name: moduleName, desc: moduleDesc } = moduleItem;
                                      return (
                                        <View className={`${prefix}-info-custom-content-item`} key={idx}>
                                            <ActiveProcess
                                              pointNum={false}
                                              headerImg={moduleImg}
                                              titleName={moduleName}
                                              content={moduleDesc}
                                              iconType={0}
                                              onLeftIconClick={this.editModule.bind(this, index, idx)}
                                              onRightIconClick={this.deleteModule.bind(this, index, idx)}
                                            ></ActiveProcess>
                                        </View>
                                      )
                                    })
                                  ) : null
                                }
                                {
                                  moduleList && moduleList.length > 0 && moduleType === 1 ? (
                                    moduleList.map((moduleItem, idx) => {
                                      const { name: moduleName, phone} = moduleItem;
                                      return (
                                        <View className={`${prefix}-info-custom-content-item`} key={idx}>
                                            <ActiveProcess
                                              pointNum={false}
                                              titleName={moduleName}
                                              tel={phone}
                                              iconType={0}
                                              onLeftIconClick={this.editModule.bind(this, index, idx)}
                                              onRightIconClick={this.deleteModule.bind(this, index, idx)}
                                            ></ActiveProcess>
                                        </View>
                                      )
                                    })
                                  ) : null
                                }
                                {
                                  moduleType === 2 ? (
                                    moduleList.map((moduleItem, idx) => {
                                      const { define_info: defineList = [] } = moduleItem;
                                      return (
                                        <View className={`${prefix}-info-custom-content-define`} key={idx}>
                                            {
                                              defineList.map((definrItem, i) => {
                                                const {type, value } = definrItem;
                                                return (
                                                  <View key={i}>
                                                      {
                                                        type === 'img' ? (
                                                          <View className={`${prefix}-info-custom-content-define-img`}>
                                                            <Image
                                                              src={value}
                                                              mode='aspectFill'
                                                              style='width: 100%;height: 366rpx;'
                                                            ></Image>
                                                          </View>
                                                        ) : (
                                                          <View className={`${prefix}-info-custom-content-define-text`}>{value}</View>
                                                        )
                                                      }
                                                  </View>
                                                )
                                              })
                                            }
                                        </View>
                                      )
                                    })
                                  ) : null
                                }
                              {
                                moduleList.length === 0 ? (
                                  <View className={`${prefix}-info-custom-content-btns`}>
                                    <View className={`${prefix}-info-custom-content-btns-add`}>
                                      <AddButton
                                        title='添加内容'
                                        type='normal'
                                        color='#EB0911'
                                        icon={1}
                                        onAddActive={this.handelEditModal.bind(this, index, moduleType, 'add')}
                                      />
                                    </View>
                                  </View>
                                ) : (
                                  <View className={`${prefix}-info-custom-content-btns`} >
                                    <View className={`${prefix}-info-custom-content-btns-add`}>
                                      <AddButton
                                        title='添加内容'
                                        type='normal'
                                        color='#EB0911'
                                        onAddActive={this.handelEditModal.bind(this, index, moduleType, 'edit')}
                                      />
                                    </View>
                                   {
                                     moduleType !== 2 ? (
                                      <View className={`${prefix}-info-custom-content-btns-change`}>
                                        <AddButton
                                          title='调整顺序'
                                          type='normal'
                                          color='#EB0911'
                                          iconType='hdlu_diaohuan'
                                          onAddActive={this.onChangeIsOpen.bind(this, index, 'moduleOpen')}
                                        />
                                      </View>
                                     ) : null
                                   }
                                  </View>
                                )
                              }
                              <View className={`${prefix}-info-custom-content-delete`} onClick={this.handelDeleteModule.bind(this, index)}>
                                删除模块
                              </View>
                            </View>
                          )
                        })
                      }
                      {
                        moduleOpen ? (
                          <FloatLayout
                            data={module}
                            option='module'
                            isOpened={moduleOpen}
                            openIndex={openIndex}
                            onClose={this.onHandleClose.bind(this, 'moduleOpen')}
                            onLeftIconClick={this.onMoveDown.bind(this, 'module')}
                            onRightIconClick={this.onMoveUp.bind(this, 'module')}
                          >
                          </FloatLayout>
                        ) : null
                      }
                    </View>
                  ) : null
                }
              <View className={`${prefix}-info-customBtn`}>
                <AddButton
                  title='自定义模块'
                  type='normal'
                  color='#EB0911'
                  onAddActive={this.onAddCustom.bind(this)}
                />
              </View>
              <View className={`${prefix}-info-btn`}>
                <MJButton
                  text='下一步'
                  color='#DFE1E6'
                  onButtonClick={this.onNextButton.bind(this, curType)}
                  disabled={isClick}
                />
              </View>
            </View>
          ) : null
        }
        {
          curType === 1 ? (
            <RegistInfo
              onNextButton={this.onNextButton.bind(this, curType)}
              onPreButton={this.onPreButton.bind(this, curType)}
            >
            </RegistInfo>
          ) : null
        }
      </View>
    )
  }
}
export default CreateAct
