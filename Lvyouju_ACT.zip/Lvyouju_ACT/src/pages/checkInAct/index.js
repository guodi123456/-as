import Taro, { Component } from '@tarojs/taro';
import { connect } from '@tarojs/redux';
import { View, Image, Text, Button } from '@tarojs/components';
import _ from 'lodash';
import { MJIcon } from '../../components';
import { getErweima } from '../../actions/actives';
import './index.scss';

@connect(({ auth }) => ({
  token : _.get(auth, 'token', ''),
  ptid : _.get(auth, 'agency_info.ptid', ''),
  uid : _.get(auth, 'uid', ''),
}), () => ({
}))
class registSign extends Component {
  constructor(props) {
    super(props);
    const params = _.get(this.$router, 'params', {});
    const { token, uid, ptid } = params;
    this.state = {
      url: '',
      pageUrl: `http://acttest.mioji.com/act/#/signin/${params.active_id}/${token}/${uid}/${ptid}`
    }
  }
    static defaultProps = {
      prefix: 'regist-erCode',
    }
    config = {
    navigationBarTitleText: '活动签到',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  componentWillReceiveProps () {
  }

  componentWillMount () {
    getErweima({
      code_type: 'B',
      scene: 'id=0&type=detail',
      page: 'pages/webView/index',
      auto_color: true,
      width: 500,
      is_hyaline: true,
      line_color: { "r":0,"g":0,"b":0 },
    }).then((res) => {
      const url =  res.data.data.qrcode_url;
      this.setState({
        url
      })
    })
  }

  componentDidShow () {
   }

  componentDidHide () { }

  saveImg = () => {
    Taro.showToast({
      title: '图片已保存',
      icon: 'success',
    })
  }

  copyUrl = () => {
    const { pageUrl } = this.state;
    Taro.setClipboardData({data: pageUrl}).then(() => {
      Taro.showToast({
        title: '复制成功',
        icon: 'none'
      })
    })
  }


  render () {
    const { prefix='regist-erCode' } = this.props;
    const { url } = this.state;
    return (
      <View className='page'>
        <View className={prefix}>
        <Text className={`${prefix}-title`}>微信扫一扫，立即签到</Text>
        {/* <Text className={`${prefix}-subtitle`}>二维码每10分钟更新一次</Text> */}
        {/* <Text className={`${prefix}-update`}>更新设置</Text> */}
        <Image src={url} className={`${prefix}-img`} />
        <Button
          className={`${prefix}-button`}
          onClick={this.saveImg}
        >
          <MJIcon
            size={46}
            type='hdlu_xiazai'
            color='#fff'
            extraStyle={{marginRight: '10rpx'}}
          />
          保存图片
        </Button>
        <View className={`${prefix}-lianjie`}>
          <View className={`${prefix}-lianjie-type`}>
            使用浏览器打开
            <Text
              className={`${prefix}-lianjie-copy`}
              onClick={this.copyUrl}
            >复制链接</Text>
          </View>
          <Text className={`${prefix}-lianjie-cont`}>{url}</Text>
        </View>
      </View>
      </View>
    )
  }
}

export default registSign
