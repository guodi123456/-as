import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import _ from 'lodash';
import { MJInput, CardHeader, MJButton } from '../../components';
import { handelChangeActiveDetailData, saveActive } from '../../actions/actives';
import './index.scss';

@connect(({ actives }) => ({
  activeDetail: _.get(actives, 'active_detail', []),
  id: _.get(actives, 'active_detail.id', ''),
}), (dispatch) => ({
  onHandelChangeActiveDetailData (query) {
    dispatch(handelChangeActiveDetailData(query))
  },
  onSaveActive (data) {
    dispatch(saveActive(data))
  },
}))
class AddContacts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      initData: {
        name: '',
        phone: ''
      }
    }
  }
  static defaultProps = {
    prefix: 'add-contacts',
  }
  config = {
    navigationBarTitleText: '新增联系人',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  componentDidMount () {
    const { activeDetail } = this.props;
    const type = _.get(this.$router, 'params.type', {});
    const moduleIndex = _.get(this.$router, 'params.moduleIndex', {});
    const listIndex = _.get(this.$router, 'params.listIndex', {});
    const moduleList = _.get(activeDetail, `module.${moduleIndex}.list.${listIndex}`, []);
    if (type === 'edit') {
      this.setState({
        initData: moduleList
      })
    }
  }


   // 编辑module信息
   onHandelChange = (option, e) => {
    const value = e.target.value;
    const { initData } = this.state;
    initData[option] = value;
    this.setState({
      initData
    })
  }
  //  确定
  saveClick = () => {
    const { initData } = this.state;
    this.saveEditModule(initData);
  }
    //保存编辑内容
    saveEditModule = (initData) => {
      const { activeDetail, id } = this.props;
      const moduleDetail = _.get(activeDetail, 'module', []);
      const type = _.get(this.$router, 'params.type', '');
      const moduleIndex = parseInt(_.get(this.$router, 'params.moduleIndex', ''));
      if (type === 'add') {
        const list = _.get(moduleDetail, `${moduleIndex}.list`, [])
        const path = `active_detail.module.${moduleIndex}.list`;
        list.push(initData);
        this.props.onHandelChangeActiveDetailData({
          path,
          value: list,
        })
      } else if (type === 'edit'){
        const listIndex = parseInt(_.get(this.$router, 'params.listIndex', {}));
        const path = `active_detail.module.${moduleIndex}.list.${listIndex}`
        this.props.onHandelChangeActiveDetailData({
          path,
          value: initData
        });
      }
      this.props.onSaveActive({ ...activeDetail, id}); 
      Taro.navigateBack();
    }

  render () {
    const { prefix='add-contacts' } = this.props;
    const { initData } = this.state;
    const {
      name,
      phone
    } = initData;
    const isClick = !name || !phone;
    return (
      <View className={prefix}>
        <View className={`${prefix}-top`}>
          <CardHeader
            title='填写信息'
            color='#EB0911'
          />
        </View>
        <View className={`${prefix}-input`}>
          <MJInput
            show
            required
            label='姓名'
            value={name}
            placeholder='请填写联系人姓名，最多10字'
            onInputChange={this.onHandelChange.bind(this, 'name')}
          />
        </View>
        <View className={`${prefix}-input`}>
          <MJInput
            show
            required
            label='联系方式'
            value={phone}
            placeholder='可填写手机号、邮箱等'
            onInputChange={this.onHandelChange.bind(this, 'phone')}
          />
        </View>
        <View className={`${prefix}-button`}>
          <MJButton
            text='确定'
            color='#DFE1E6'
            onButtonClick={this.saveClick.bind(this)}
            disabled={isClick}
          />
        </View>
      </View>
     
    )
  }
}

export default AddContacts
