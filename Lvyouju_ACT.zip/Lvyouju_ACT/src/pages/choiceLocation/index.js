import Taro, { Component } from '@tarojs/taro';
import { View, Input } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import _ from 'lodash';
import { MJIcon, CardHeader, Suggestion } from '../../components';
import QQMapWX from '../../tcMap/qqmap-wx-jssdk';
import { handelChangeActiveDetailData, requestCommonCities, getSuggestion, saveActive } from '../../actions/actives';
import './index.scss';


@connect(({ actives }) => ({
  activeDetail: _.get(actives, 'active_detail', {}),
  commonCitys: _.get(actives, 'common_citys.list', []),
}), (dispatch) => ({
  onHandelChangeActiveDetailData(data) {
    dispatch(handelChangeActiveDetailData(data))
  },
  onRequestCommonCities(query) {
    dispatch(requestCommonCities(query))
  },
  onGetSuggestion(query) {
    dispatch(getSuggestion(query))
  },
  onSaveActive (data) {
    dispatch(saveActive(data))
  },
}))
class ChoiceLocation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      chooseCity: true,
      markers: [],
      curId: '20001',
      isInit: true
    }
  }
    static defaultProps = {
      prefix: 'choice-location',
      stepList: [],
      maxLength: '15',
      
    }
    config = {
    navigationBarTitleText: '选择地点',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  componentWillReceiveProps () {
  }

  componentWillMount () {}

  componentDidShow () {
   }

  componentDidHide () { }

  componentWillMount () {
    this.props.onRequestCommonCities();
  }

  // 腾讯地图搜索api
  handelSearch = (e) => {
    const { activeDetail } = this.props;
    const city_name = _.get(activeDetail, 'base_info.address.city_name') || '北京';
    const value = e.target.value
    let mks =[];
    let _this = this;
    let qqmapsdk = new QQMapWX({
      key: 'MXLBZ-CJ2R4-6THUA-DOVCH-IW4XV-ZXF67'
    })
    Taro.getLocation({
      type: 'wgs84',
      success(res) {
　　　　　_this.setState({
　　　　　　latitude:res.latitude,
          longitude:res.longitude
        })
      }
    })
     //这里声明下_this，使用taro的this.直接操作到微信调试工具会报错(可能是我姿势不对)
    qqmapsdk.search({
    keyword: value,
    region: city_name,
    success: function (res) {
      mks =[];
      for (let i =0; i < res.data.length; i++) { 
        mks.push({ 
          title: res.data[i].title,
          address: res.data[i].address,
          coord: `${res.data[i].location.lat},${res.data[i].location.lng}`,
          city_name: res.data[i].ad_info.city,
          id: res.data[i].id, 
          latitude: res.data[i].location.lat, 
          longitude: res.data[i].location.lng, 
          iconPath: '/resources/my_marker.png', //图片路径
          width: 20,
          height: 20
        })
      };
      _this.setState({ markers: mks, isInit: false })
      console.log(res)
    },
    fail: function (res) { console.log(res) },
    complete: function (res) { console.log(res) } 
  })
}

// 选中信息
getAddress = (city_name, name, coord, detail_address) => {
  const address = {city_name, name, coord, detail_address};
  const { activeDetail } = this.props;
  const id = _.get(this.$router, 'params.id', '');
  this.props.onHandelChangeActiveDetailData({
    value: address,
    path: 'active_detail.base_info.address'
  })
  this.props.onSaveActive({ ...activeDetail, id}); 
  Taro.navigateBack(); 
}

// 切换到城市内容
changeCity = () => {
  const { chooseCity } = this.state;
  this.setState({
    chooseCity: !chooseCity
  })
}

// 更改选中城市
changeCitySelect = (item) => {
  const { id, name, coord } = item;
  const { curId, chooseCity } = this.state;
  if (id === curId) {
    this.setState({
      curId: ''
    })
  } else {
    this.setState({
      curId: id
    })
  }
  this.props.onHandelChangeActiveDetailData({
    value: name,
    path: 'active_detail.base_info.address.city_name'
  })
  this.props.onHandelChangeActiveDetailData({
    value: coord,
    path: 'active_detail.base_info.address.coord'
  })
  this.setState({
    chooseCity: !chooseCity
  })
}

suggestionSelect = (item) => {
  const { name, coord } = item;
  const { chooseCity } = this.state;
  this.props.onHandelChangeActiveDetailData({
    value: name,
    path: 'active_detail.base_info.address.city_name'
  })
  this.props.onHandelChangeActiveDetailData({
    value: coord,
    path: 'active_detail.base_info.address.coord'
  })
  this.setState({
    chooseCity: !chooseCity,
    isInit: false
  })
}

requestSuggestion = (key) => {
  const { onGetSuggestion } = this.props;
  return onGetSuggestion('g203', {
    data: 3,
    match: 3,
    num: 50,
    key,
  });
}


  render () {
    const { prefix='choice-location', commonCitys, activeDetail } = this.props;
    const city_name = _.get(activeDetail, 'base_info.address.city_name') || '北京';
    const { chooseCity, markers, curId, isInit } = this.state;
    return (
      <View className={prefix}>
        {
          chooseCity ? (
            <View className={`${prefix}-search`}>
              <View className={`${prefix}-search-head`}>
              <View className={`${prefix}-search-head-city`} onClick={this.changeCity.bind(this)}>
                <View className={`${prefix}-search-head-city-icon`}>
                  <MJIcon
                    type='hdlu_zuobiao'
                    color='#272C33'
                    size={40}
                  >
                  </MJIcon>
                </View>
                <View className={`${prefix}-search-head-city-name`}>{city_name}</View>
                <View className={`${prefix}-search-head-city-select`}>
                  <MJIcon
                    type='hdlu_zhankai'
                    color='#272C33'
                    size={40}
                  >
                  </MJIcon>
                </View>
              </View>
              <View className={`${prefix}-search-head-search`}>
                <View className={`${prefix}-search-head-search-icon`}>
                  <MJIcon
                    type='hdlu_sousuo'
                    color='#C9CED6'
                    size={40}
                  >
                  </MJIcon>
                </View>
                <View className={`${prefix}-search-head-search-input`}>
                  <Input
                    placeholder='搜索'
                    onInput={this.handelSearch.bind(this)}
                  ></Input>
                </View>
              </View>
            </View>
              <View className={`${prefix}-search-content`}>
                {
                  markers && markers.length > 0 ? (
                    <View className={`${prefix}-search-content-item`}>
                      {
                        markers.map((item, index) => {
                          const { title, address, coord, city_name: cityName } = item;
                          return (
                            <View className={`${prefix}-search-content-item-content`} key={index} onClick={this.getAddress.bind(this, cityName, title, coord, address)}>
                              <View className={`${prefix}-search-content-item-content-title`}>{title}</View>
                              <View className={`${prefix}-search-content-item-content-address`}>{address}</View>
                            </View>
                          )
                        })
                      }
                    </View>
                  ) : 
                    !isInit ?
                    <View className={`${prefix}-search-content-none`}>
                      未找到相关地点
                    </View> : null
                }
              </View>
            </View>
          ) : (
            <View className={`${prefix}-citys`}>
              <View className={`${prefix}-citys-city`}>
                <CardHeader 
                  title='选择城市'
                  color='#EB0911'
                />
                <View>取消</View>
              </View>
              <View className={`${prefix}-citys-search`}>
                <Suggestion
                  placeholderClass={`${prefix}-citys-search-placeholder`}
                  placeholder='搜“东京”试试'
                  getSuggestion={this.requestSuggestion.bind(this)}
                  onSelect={this.suggestionSelect.bind(this)}
                />
              </View>
              <View className={`${prefix}-citys-usecity`}>
                常用城市
              </View >
              <View className={`${prefix}-citys-cityitem`}>
                { 
                  commonCitys.map((item, index)=>{
                    const { name, id } =item
                    return(
                      <View
                        className={`${prefix}-citys-cityitem-info ${id === curId ? 'selectCity' : ''}`}
                        key={index}
                        onClick={this.changeCitySelect.bind(this, item)}
                      >
                        {name}
                      </View>
                    )
                  })
                
                }
              </View>
            </View>
          )
        }
      </View>
     
    )
  }
}
export default ChoiceLocation