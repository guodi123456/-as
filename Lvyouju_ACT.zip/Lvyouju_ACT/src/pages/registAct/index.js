import Taro, { Component } from '@tarojs/taro';
import { View, Image, Text, Button} from '@tarojs/components';
import _ from 'lodash';
import { MJIcon } from '../../components';
import { getErweima } from '../../actions/actives';
import MioJi from '../../assets/image/logo.png';
import './index.scss';

// @connect(({ counter }) => ({
//   counter
// }), (dispatch) => ({
//   doLogin (query) {
//     dispatch(doLogin(query))
//   },
// }))
class RegistAct extends Component {
  constructor(props) {
    super(props);
    this.state = {}
  }
    static defaultProps = {
      prefix: 'regist-erCode',
    }
    config = {
    navigationBarTitleText: '活动报名',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  componentWillReceiveProps (nextProps) {
    console.log(this.props, nextProps)
  }

  componentWillMount () {
    // const active_id = _.get(this.$router, 'params.active_id', '');
    // const Url = encodeURI(`10.2.4.63:3019/act/#/detail/${active_id}/2`);
    getErweima({
      code_type: 'B',
      scene: 'id=1&type=detail',
      page: 'pages/webView/index',
      auto_color: true,
      width: 500,
      is_hyaline: true,
      line_color: { "r":0,"g":0,"b":0 },
    }).then((res) => {
      const url =  res.data.data.qrcode_url
      this.setState({
        url
      })
    })
  }

  componentDidShow () {
   }

  componentDidHide () { }
  componentDidMount () {
  }


  saveImage = () => {
    const { url } = this.state;
    Taro.showLoading({
      title: '保存中...'
    })
    Taro.downloadFile({
      url,
      success: function (res) {
        //图片保存到本地
        Taro.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success: function () {
            Taro.hideLoading()
            Taro.showToast({
              title: '',
              content: '图片已保存',
              showCancel:false,
            })
          },
          fail: function (err) {
            if (err.errMsg === "saveImageToPhotosAlbum:fail:auth denied" || err.errMsg === "saveImageToPhotosAlbum:fail auth deny") {
              // 这边微信做过调整，必须要在按钮中触发，因此需要在弹框回调中进行调用
              Taro.showModal({
                title: '提示',
                content: '需要您授权保存相册',
                showCancel: false,
                success:()=>{
                  Taro.openSetting({
                    success(settingdata) {
                      if (settingdata.authSetting['scope.writePhotosAlbum']) {
                        Taro.showModal({
                          title: '提示',
                          content: '获取权限成功,再次点击图片即可保存',
                          showCancel: false,
                        })
                      } else {
                        Taro.showModal({
                          title: '提示',
                          content: '获取权限失败，将无法保存到相册哦~',
                          showCancel: false,
                        })
                      }
                    },
                    fail(failData) {
                      console.log("failData",failData)
                    },
                    complete(finishData) {
                      console.log("finishData", finishData)
                    }
                  })
                }
              })
            }
          },
          complete() {
            Taro.hideLoading()
          }
        })
      }
    })
  }

  render () {
    const { prefix='regist-erCode' } = this.props;
    return (
      <View className='page'>
        <View className={prefix}>
          <Text className={`${prefix}-title`}>报名二维码</Text>
          <Text className={`${prefix}-subtitle`}>微信扫一扫，报名活动</Text>
          <Image src={MioJi} className={`${prefix}-img`} />
          <Button
            className={`${prefix}-button`}
            onClick={this.saveImage}
          >
            <MJIcon
              size={46}
              type='hdlu_xiazai'
              color='#fff'
              extraStyle={{marginRight: '10rpx'}}
            />
            保存图片
          </Button>

        </View>
      </View>
    )
  }
}

export default RegistAct
