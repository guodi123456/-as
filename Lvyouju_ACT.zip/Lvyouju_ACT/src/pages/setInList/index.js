import Taro, { Component } from '@tarojs/taro';
import { AtTabs, AtTabsPane } from 'taro-ui';
import { connect } from '@tarojs/redux';
import { View } from '@tarojs/components';
import _ from 'lodash';
import { PeopleList } from '../../components';
import { requestContactInfo } from "../../actions/actives";
import { searchPeopleList } from '../../utils'
import './index.scss';

const tabList = [{
  type: 0,
  title: '待出席',
}, {
  type: 1,
  title: '已签到',
}];

let inputVal = '';
@connect(({ actives }) => ({
  contactData: _.get(actives, 'contact_data', {}),
  }), (dispatch) => ({
    onRequestContactInfo (query) {
      dispatch(requestContactInfo(query))
    },
  }))
class SetInList extends Component {
  constructor(props) {
    super(props);
    const params = _.get(this.$router, 'params', {});
    this.state = {
      searchList: [],
      isSearch: false,
      current: 0,
      flag: true,
      active_id: params.active_id,
      state_tab: +params.activeType
    }
  }
    static defaultProps = {
      prefix: 'setIn-info',
    }
    config = {
    navigationBarBackgroundColor: '#FAFAFA',
    navigationBarTitleText: '签到名单'
  }

  componentWillReceiveProps (nextProps) {
    console.log(this.props, nextProps)
  }

  componentWillMount () {
    // 获取审核名单信息
    this.getRequestInfo(5)
  }

  componentDidShow = () => {
    this.Interval = setInterval(() => this.getRequestInfo(5), 5000)
  }

  componentDidHide = () => {
    clearInterval(this.Interval);
  }

  componentWillUnmount = () => {
    clearInterval(this.Interval);
  }

  getRequestInfo = (mode) => {
    this.props.onRequestContactInfo({
      mode,
      id: this.state.active_id,
      status: this.state.state_tab,
      filter: {key: ''}
    });
  }

  handleClick (value) {
    let _flag = value === 0 ? true : false;
    const mode = 5 - value;
    this.getRequestInfo(mode);
    this.setState({
      current: value,
      flag: _flag,
      isSearch: false
    })
    if(this.Interval) {
      clearInterval(this.Interval)
    }
    this.Interval = setInterval(() => this.getRequestInfo(mode), 5000)
  }

  // 获取搜索框value 
  getSearchCont = (val) => {
    inputVal = val;
    if (!val.trim()) {
      this.setState({
        isSearch: false
      })
    }
  }
  // 搜索查询
  seachClick = async (mode) => {
    if(!inputVal.trim()) {
      return;
    }
    const { active_id, state_tab } = this.state;
    const res = await searchPeopleList(active_id, mode, inputVal, +state_tab);
    this.setState({
      searchList: res.data.data.list,
      isSearch: true
    })
  }

  render () {
    const { prefix='setIn-info', contactData } = this.props;
    const { isSearch, searchList, flag, active_id } = this.state;
    const list = isSearch ? searchList : contactData;
    return (
      <View className={prefix}>
        <View className={`${prefix}-tab`}>
          <AtTabs
            current={this.state.current}
            tabList={tabList}
            onClick={this.handleClick.bind(this)}
            tabDirection='horizontal'
            animated={false}
          >
            <AtTabsPane current={this.state.current} index={0} >
              <View className={`${prefix}-tab-content`}>
                {
                  flag ? 
                  <PeopleList
                    people_list={list}
                    num={list.length}
                    title='待出席'
                    isSearched={isSearch}
                    activeId={active_id}
                    onInputChange={this.getSearchCont.bind(this)}
                    onInputClick={this.seachClick.bind(this, 5)}
                  /> : null
                }
              </View>
            </AtTabsPane>
            <AtTabsPane current={this.state.current} index={1}>
              <View className={`${prefix}-tab-content`}>
                {
                  !flag ?
                  <PeopleList
                    people_list={list}
                    num={list.length}
                    title='已签到'
                    isSearched={isSearch}
                    activeId={active_id}
                    onInputChange={this.getSearchCont.bind(this)}
                    onInputClick={this.seachClick.bind(this, 4)}
                  /> : null
                }
              </View>
            </AtTabsPane>
          </AtTabs>
        </View>  
      </View>
    )
  }
}

export default SetInList
