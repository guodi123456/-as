import Taro, { Component } from '@tarojs/taro';
import { View, Image,Text } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import _ from 'lodash';
import { MJInput } from '../../components';
import { doLogin, setAuth } from '../../actions';
import MioJi from '../../assets/image/logo.png';
import navigate from '../../utils/navigate';
import './index.scss';

@connect(({ auth }) => ({
  stat: _.get(auth, 'stat', {})
}), (dispatch) => ({
  onDoLogin (query) {
    dispatch(doLogin(query))
  },
  onSetAuth (query) {
    dispatch(setAuth(query))
  },
}))
class Index extends Component {
  constructor(props) {
    super(props);
    this.state = {
      type: 'password',
      account: '',
      password: '',
      nameErrorStyle: false,
      passwordErrorStyle: false
    }
  }
    static defaultProps = {
      prefix: 'app-login',
    }
    config = {
    navigationBarTitleText: '旅业活动',
    navigationBarBackgroundColor: '#FAFAFA',
  }


  componentWillMount () {
    const userInfo = Taro.getStorageSync('userInfo') || '';
    if (userInfo) {
      this.props.onSetAuth(userInfo)
      navigate({
        page: 'actives',
      })
    }
  }

  componentDidShow () {
   }

  componentDidHide () { }

  handleChange(option, e) {
    const value = e.target.value;
    this.setState({
      [option]: value,
    })
    if(option === 'account' && value) {
      this.setState({
        nameErrorStyle: false,
      })
    } else if (option === 'password' && value){
      this.setState({
        passwordErrorStyle: false,
      })
    }
  }

// logo
  login = () => {
    const { account, password } = this.state;
    if (!account) {
      this.setState({
        nameErrorStyle: true
      })
    }
    if (!password) {
      this.setState({
        passwordErrorStyle: true
      })
    }
    const query = {
      account,
      password
    };
    if (account && password) {
      this.props.onDoLogin(query);
    }
  }
  
  // 展示报错信息
  logoInfo = (stat) => {
    let showinfo = '';
    if (stat === 1) {
      showinfo = '帐号不存在'
    } else if (stat === 2) {
      showinfo = '帐号已停用'
    } else if (stat === 3){
      showinfo='密码错误'
    } else {
      showinfo=''
    }
    return showinfo
  }

  handleChangeType = () => {
    const { type } = this.state;
    if(type === 'text') {
      this.setState({
        type: 'password'
      })
    } else {
      this.setState({
        type: 'text'
      })
    }
  }
  
  
  render () {
    const { prefix='app-login', stat } = this.props;
    const { nameErrorStyle, passwordErrorStyle, account, password, type } = this.state;
    return (
      <View className={prefix}>
        <Image
          className={`${prefix}-image`}
          src={MioJi}
          mode='aspectFit'
        />
        <Text className={`${prefix}-text`}>活动管理系统</Text>
        <View className={`${prefix}-username`}>
        <MJInput   
          placeholder='请输入手机号/邮箱'
          option='account'
          type='text'
          value={this.state.account}
          onInputChange={this.handleChange.bind(this, 'account')}
          showNumber={false}
          errorStyle={nameErrorStyle}
        />
        </View>
        <View className={`${prefix}-passowrd`}>
        <MJInput
          placeholder='请输入密码'
          option='password'
          value={this.state.password}
          type={type}
          onInputChange={this.handleChange.bind(this, 'password')}
          showNumber={false}
          showpassword={1}
          errorStyle={passwordErrorStyle}
          onHandelChangeType={this.handleChangeType.bind(this)}
        />
        </View>
        {
         stat ? (
            <View className={`${prefix}-info`}>{this.logoInfo(stat)}</View>
          ) : null
        }
          
        <View className={`${prefix}-button ${(account && password) ? '' : 'disabled'}`} onClick={this.login.bind(this)}>
            登录
        </View>
      </View>
     
    )
  }
}

export default Index
