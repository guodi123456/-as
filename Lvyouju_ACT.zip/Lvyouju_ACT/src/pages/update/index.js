import Taro, { Component } from '@tarojs/taro'
import { View, Text } from '@tarojs/components'
import updateApp from '../../utils/updateApp'
import './index.scss'

class Update extends Component {
  componentDidMount() {
    updateApp();
  }
  render () {
    return (
      <View className='update'>
        <View>
          <Text>新版本已经准备好</Text>
        </View>
        <View>
          <Text>正在帮您进行自动更新...</Text>
        </View>
      </View>
    )
  }
}

export default Update
