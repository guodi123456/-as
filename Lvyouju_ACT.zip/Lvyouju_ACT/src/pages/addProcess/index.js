import Taro, { Component } from '@tarojs/taro';
import { View ,Picker, Button} from '@tarojs/components';
import moment from 'moment';
import { connect } from '@tarojs/redux';
import _ from 'lodash';
import { CardHeader, MJIcon, MJInput, Textarea } from '../../components'
import dateFormater from '../../utils/formatDate';
import { handelChangeActiveDetailData, saveActive } from '../../actions/actives';
import './index.scss';

@connect(({ actives }) => ({
  activeDetail: _.get(actives, 'active_detail', {}),
  id: _.get(actives, 'active_detail.id', ''),
}), (dispatch) => ({
  onHandelChangeActiveDetailData(data) {
    dispatch(handelChangeActiveDetailData(data))
  },
  onSaveActive (data) {
    dispatch(saveActive(data))
  },
}))
class AddProcess extends Component {
  constructor(props) {
    super(props);
    this.state = {
      initFlowItem: {
        date: '',
        title: '',
        start_time: '',
        end_time: '',
        define: [
        ]
      }
  }
}
  static defaultProps = {
      prefix: 'add-process',
    }
    config = {
    navigationBarTitleText: '流程编辑',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  componentWillMount () {
    const date = _.get(this.$router, 'params.date', {});
    if (date) {
      const { initFlowItem } = this.state;
      initFlowItem.date = date
      this.setState({
        initFlowItem
      });
    }
  }

  componentDidMount (){
    const { activeDetail } = this.props;
    const flowType = _.get(this.$router, 'params.type', {});
    const flowIndex = _.get(this.$router, 'params.flow_index', {});
    const listIndex = _.get(this.$router, 'params.list_index', {});
    const flowList = _.get(activeDetail, `flow.${flowIndex}.list.${listIndex}`, [])
    if (flowType === 'edit') {
      this.setState({
        initFlowItem: flowList
      })
    }
  }

  // 更改流程信息
  changeFlowData = (option, e) => {
    const { initFlowItem } = this.state;
    const value = e.target.value;
    initFlowItem[option] = value;
    this.setState({
      initFlowItem,
    });
  }


  // 更改自定义信息
  changeDefineDate = (index, e) => {
    const value = e.target.value;
    const { initFlowItem } = this.state;
    initFlowItem.define[index] = value;
    this.setState({
      initFlowItem,
    });
  }

  //添加自定义信息
  addDefineInfo = () => {
    const { initFlowItem } = this.state;
    initFlowItem.define.push('');
    this.setState({
      initFlowItem,
    })
  }

  //删除自定义信息
  deleteDefineInfo = (index) => {
    const { initFlowItem } = this.state;
    initFlowItem.define.splice(index, 1)
    this.setState({
      initFlowItem,
    });
  }

  confirm = () => {
    const { initFlowItem } = this.state;
    const { activeDetail, id } = this.props;
    const flowType = _.get(this.$router, 'params.type', {});
    const initDate = _.get(activeDetail, 'base_info.start_date')
    let flowIndex = parseInt(_.get(this.$router, 'params.flow_index', {}));
    if (flowType === 'add') {
      const flow = _.get(activeDetail, 'flow', []);
      const list = _.get(activeDetail, `flow.${flowIndex}.list`, []);
      const curDate = initFlowItem.date || initDate;
      const dateIndex = flow.findIndex((item) => {
        return item.date === curDate
      })
      if (dateIndex === -1) {
        let nextList = [];
        if (list.length > 0) {
          flowIndex = flow.length;
          nextList.push(initFlowItem);
        } else {
          nextList.push(initFlowItem);
        }
        const curFlow = {
          list: nextList,
          date: curDate
        }
        this.props.onHandelChangeActiveDetailData({
          path: `active_detail.flow.${flowIndex}`,
          value: curFlow
        });
       
      } else {
        list.push(initFlowItem);
        this.props.onHandelChangeActiveDetailData({
          path: `active_detail.flow.${dateIndex}.list`,
          value: list
        });
      }
    } else {
      const listIndex = parseInt(_.get(this.$router, 'params.list_index', {}));
      this.props.onHandelChangeActiveDetailData({
        path: `active_detail.flow.${flowIndex}.list.${listIndex}`,
        value: initFlowItem
      });
    }
    this.props.onSaveActive({ ...activeDetail, id});
    Taro.navigateBack();
  }

  render () {
    const { prefix='add-process', activeDetail } = this.props;
    const { initFlowItem } = this.state;
    const flowIndex = _.get(this.$router, 'params.flow_index', {});
    const initDate =  _.get(activeDetail, `flow.${flowIndex}.date`) || _.get(activeDetail, 'base_info.start_date');
    const {
      title,
      date = initDate,
      start_time,
      end_time,
      define,
    } = initFlowItem;
    return (
      <View className={prefix}>
        <CardHeader
          title='活动流程'
          color='#EB0911'
        ></CardHeader>
        <View className={`${prefix}-process-item`}>
           <View className={`${prefix}-process-item-label`}>
              <View className={`${prefix}-process-item-label-text`}>活动日期</View>
              <View className={`${prefix}-process-item-label-required`}>*</View>
           </View>
           <View className={`${prefix}-process-item-content`} >
              <View className={`${prefix}-process-item-content-picker`}>
                <Picker
                  mode='date'
                  start={moment().format('YYYY-MM-DD')}
                  end={moment().add(3, 'years').format('YYYY-MM-DD')}
                  onChange={this.changeFlowData.bind(this, 'date')}
                >
                  <View className={`${prefix}-process-item-content-picker`}>
                      {date ? dateFormater(date, ['年', '月', '日'], true, true) : '请选择活动日期' }
                  </View>
                </Picker>
              </View>         
              <View className={`${prefix}-process-item-content-icon`}>
                <MJIcon
                  type='hdlu_zhankai'
                  color='#EB0911'
                  size={40}
                /> 
              </View>
           </View>
        </View>
        <View className={`${prefix}-process-item`}>
           <View className={`${prefix}-process-item-label`}>
              <View className={`${prefix}-process-item-label-text`}>开始时间</View>
              <View className={`${prefix}-process-item-label-required`}>*</View>
           </View>
           <View className={`${prefix}-process-item-content`}>  
              <View className={`${prefix}-process-item-content-picker`}>
                <Picker
                  mode='time'
                  onChange={this.changeFlowData.bind(this, 'start_time')}
                >
                  <View className={`${prefix}-process-item-content-picker`}>
                      {start_time || '请选择开始时间'}
                  </View>
                </Picker>
              </View>
              <View className={`${prefix}-process-item-content-icon`}>
                <MJIcon
                  type='hdlu_zhankai'
                  color='#EB0911'
                  size={40}
                /> 
              </View>
           </View>
        </View>
        <View className={`${prefix}-process-item`}>
           <View className={`${prefix}-process-item-label`}>
              <View className={`${prefix}-process-item-label-text`}>结束时间</View>
              <View className={`${prefix}-process-item-label-required`}>*</View>
           </View>
           <View className={`${prefix}-process-item-content`}>   
              <View>
                <Picker className={`${prefix}-process-item-content-picker`}
                  mode='time'
                  onChange={this.changeFlowData.bind(this, 'end_time')}
                >
                  <View className={`${prefix}-process-item-content-picker`}>
                      {end_time || '请选择结束时间'}
                  </View>
                </Picker>
              </View>           
              <View className={`${prefix}-process-item-content-icon`}>
                    <MJIcon
                      type='hdlu_zhankai'
                      color='#EB0911'
                      size={40}
                    /> 
                 </View>
           </View>
           
        </View>
        <View className={`${prefix}-process-item`}>
           <View className={`${prefix}-process-item-label`}>
              <View className={`${prefix}-process-item-label-text`}>主题</View>
              <View className={`${prefix}-process-item-label-required`}>*</View>
           </View>
           <View className={`${prefix}-process-item-titleContent`}>              
              <View className={`${prefix}-process-item-titleContent-textarea`}>
                <Textarea
                  placeholder='请填写流程内容，最多50个字'
                  className={`${prefix}-process-item-titleContent-textarea-text`}
                  autoHeight
                  onInput={this.changeFlowData.bind(this, 'title')}
                  value={title}
                  maxlength={100}
                  placeholderClass={`${prefix}-process-item-titleContent-textarea-text-placeholder`}
                ></Textarea>
              </View>
              <View className={`${prefix}-process-item-titleContent-number`}>
                {title.length}/50
              </View>
           </View>
        </View>
        <View className={`${prefix}-process-info`}>
           <CardHeader
             title='自定义信息'
             color='#EB0911'
           />
           {
             define && define.length > 0 ? (
               define.map((value, index) => {
                 return (
                  <View key={index}>
                    <View className={`${prefix}-process-info-title`}>
                      <View className={`${prefix}-process-info-title-icon`} onClick={this.deleteDefineInfo.bind(this, index)}>
                          <MJIcon type='hdlu_yichu' color='#EB0911' size={32} />
                      </View>
                      <View className={`${prefix}-process-info-title-text`}>自定义信息</View>
                    </View>
                    <View className={`${prefix}-process-info-content`}>
                      <View className={`${prefix}-process-info-content-text`}>填写内容</View>
                      <View className={`${prefix}-process-info-content-input`}>
                      <MJInput  
                        placeholder='可填写主讲信息等，最多100字'
                        type='text'
                        showNumber
                        maxnumber={100}
                        style='width: 100%'
                        value={value}
                        onInputChange={this.changeDefineDate.bind(this, index)}
                      />
                      </View>
                    </View>

                  </View>
                 )
                })
             ) : null
           }
        </View> 
        <View className={`${prefix}-process-infoadd`} onClick={this.addDefineInfo.bind(this)}>
          <View className={`${prefix}-process-infoadd-add`}>+</View>
           <View className={`${prefix}-process-infoadd-title`}>添加信息</View>
        </View>
        <Button
          className={`${prefix}-process-button`}
          onClick={this.confirm.bind(this)}
          disabled={!title || !start_time || !end_time}
        >
          确定
        </Button>
     </View>

    )
  }
}

export default AddProcess
