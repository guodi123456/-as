import Taro, { Component } from '@tarojs/taro';
import { AtTabs, AtTabsPane } from 'taro-ui';
import { connect } from '@tarojs/redux';
import { View, Button } from '@tarojs/components';
import _ from 'lodash';
import { PeopleList, MJIcon } from '../../components';
import { searchPeopleList } from '../../utils'
import navigate from '../../utils/navigate';
import request from '../../utils/request'
import { requestContactInfo } from "../../actions/actives";
import './index.scss';

const tabList = [{
  type: 0,
  title: '审核未通过',
}, {
  type: 1,
  title: '已出席',
}, {
  type: 2,
  title: '未出席',
}];
let inputVal = '';
@connect(({ actives }) => ({
  contactData: _.get(actives, 'contact_data', {}),
  }), (dispatch) => ({
    onRequestContactInfo (query) {
      dispatch(requestContactInfo(query))
    },
  }))
class ParticipantList extends Component {
  constructor(props) {
    super(props);
    const params = _.get(this.$router, 'params', {});    
    const { active_id, examine_status, activeType } = params;
    let arr = _.cloneDeep(tabList);
    +examine_status === 0 && arr.splice(0, 1);
    this.state = {
      searchList: [],
      isSearch: false,
      current: 0,
      state_tab: +activeType,
      flag: 1 - examine_status,
      active_id: active_id,
      tab_list: arr,
      ifHave: false,
      verify: examine_status
    }
  }
    static defaultProps = {
      prefix: 'setIn-info',
    }
    config = {
    navigationBarBackgroundColor: '#FAFAFA',
    navigationBarTitleText: '参与者信息'
  }

  componentWillReceiveProps (nextProps) {
    console.log(this.props, nextProps)
  }

  componentWillMount () {
    // 获取审核名单信息
    const { active_id, state_tab } = this.state;
    this.props.onRequestContactInfo({
      mode: 2,
      id: active_id,
      status: state_tab,
      filter: {key: ''}
    });
    this.getDownloadStatus(active_id);
  }

  getDownloadStatus = async (id) => {
    const res = await request({
      type: 'api45715',
      query: {
        id
      }
    })
    if (!res.data.data.url) {
      this.setState({
        ifHave: true
      })
    }  
  }

  handleClick (value) {
    const { onRequestContactInfo } = this.props;
    const { verify, state_tab } = this.state;
    let mode;
    if(+verify === 1) {
      mode = value === 0 ? 2 : value === 1 ? 4 : 5
    } else {
      mode = value === 0 ? 4 : 5;
    }
    onRequestContactInfo({
      mode,
      status: +state_tab,
      id: this.state.active_id,
      filter: {key: ''}
    });


    this.setState({
      current: value,
      flag: +verify === 1 ? value : value + 1,
      isSearch: false
    })
  }

    // 获取搜索框value 
    getSearchCont = (val) => {
    inputVal = val;
    
    if (!val.trim()) {
      this.setState({
        isSearch: false
      })
    }
  }
  // 搜索查询
  seachClick = async (mode) => {
    if(!inputVal.trim()) {
      return;
    }
    const { active_id, state_tab } = this.state;
    const res = await searchPeopleList(active_id, mode, inputVal, +state_tab);
    this.setState({
      searchList: res.data.data.list,
      isSearch: true
    })
  }

  downLoadClick = () => {
    navigate({
      page: 'downloadInfo',
      param: {
        active_id: this.state.active_id
      }
    })
  }
  render () {
    const { prefix='setIn-info', contactData } = this.props;
    const { isSearch, searchList, flag, verify, tab_list, ifHave, active_id } = this.state;
    const list = isSearch ? searchList : contactData;
    return (
      <View className={prefix}>
        <View className={`${prefix}-tab`}>
          <AtTabs
            current={this.state.current}
            tabList={tab_list}
            onClick={this.handleClick.bind(this)}
            tabDirection='horizontal'
            animated={false}
          >
            {
              verify == 1 ? 
              <AtTabsPane current={this.state.current} index={0} >
                <View className={`${prefix}-tab-content`}>
                  {
                    flag === 0 ?
                    <PeopleList
                      people_list={list}
                      num={list.length}
                      title='审核未通过'
                      isSearched={isSearch}
                      activeId={active_id}
                      onInputChange={this.getSearchCont.bind(this)}
                      onInputClick={this.seachClick.bind(this, 2)}
                    /> : null
                  }
                </View>
              </AtTabsPane> : null
            }
            <AtTabsPane current={this.state.current} index={1}>
            <View className={`${prefix}-tab-content`}>
                {
                  flag === 1 ?
                  <PeopleList
                    people_list={list}
                    num={list.length}
                    title='已出席'
                    isSearched={isSearch}
                    activeId={active_id}
                    onInputChange={this.getSearchCont.bind(this)}
                    onInputClick={this.seachClick.bind(this, 4)}
                  /> : null
                }
              </View>
            </AtTabsPane>
            <AtTabsPane current={this.state.current} index={2}>
            <View className={`${prefix}-tab-content`}>
                {
                  flag === 2 ?
                  <PeopleList
                    people_list={list}
                    num={list.length}
                    title='未出席'
                    isSearched={isSearch}
                    activeId={active_id}
                    onInputChange={this.getSearchCont.bind(this)}
                    onInputClick={this.seachClick.bind(this, 5)}
                  /> : null
                }
              </View>
            </AtTabsPane>
          </AtTabs>
        </View>
        <View className={`${prefix}-tab-button`}>
          <Button
            className={`${prefix}-tab-button-btn`}
            disabled={ifHave}
            onClick={this.downLoadClick.bind(this)}
          >
            <MJIcon
              type='hdlu_xiazai'
              size={56}
              color='#fff'
            />
            下载参与者信息
          </Button>
        </View>
      </View>
    )
  }
}

export default ParticipantList
