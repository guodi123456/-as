import Taro, { Component } from '@tarojs/taro';
import { connect } from '@tarojs/redux';
import { View, Button, Text, Textarea } from '@tarojs/components';
import _ from 'lodash';
import { MJIcon, CardHeader, UploadImage } from '../../components';
import { handelChangeActiveDetailData, saveActive } from '../../actions/actives';
import './index.scss';

@connect(({ actives }) => ({
  activeDetail: _.get(actives, 'active_detail', {}),
  id: _.get(actives, 'active_detail.id', ''),
}), (dispatch) => ({
  onHandelChangeActiveDetailData (query) {
    dispatch(handelChangeActiveDetailData(query))
  },
  onSaveActive (data) {
    dispatch(saveActive(data))
  },
}))
class CustomPicText extends Component {
  static defaultProps = {
    prefix: 'custom-picText',
  }
  config = {
    navigationBarTitleText: '新增信息',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  constructor(props) {
    super(props);
    this.state = {
      customList: [],
      addText: [{
        value: '添加图片',
        type: 'img'
      }, {
        value:'添加文本',
        type: 'text'
      }],
      customType: ['自定义图片', '自定义文本']
    }
  }
  saveClick = () => {
    const { customList } = this.state;
    this.saveEditModule(customList);
  }
  componentDidMount = () => {
    const module_type = _.get(this.props.activeDetail, 'module', []);
    let new_addText = [];
    module_type.forEach((item) => {
      if(item.module_type === 2) {
        item.list && item.list.forEach((_item) => {
          if(_item.define_info.length) {
            new_addText = _item.define_info;
          }
        })
      }
    });
    if(new_addText.length) {
      this.setState({
        customList: new_addText
      })
    }
  }
  //保存编辑内容
  saveEditModule = (initData) => {
    const { activeDetail, id } = this.props;
    const moduleDetail = _.get(activeDetail, 'module', []);
    const moduleIndex = parseInt(_.get(this.$router, 'params.moduleIndex', ''));
    const type = _.get(this.$router, 'params.type', {});
    if (type === 'add') {
      const list = _.get(moduleDetail, `${moduleIndex}.list`, [])
      const path = `active_detail.module.${moduleIndex}.list`;
      list.push({'define_info':initData});
      this.props.onHandelChangeActiveDetailData({
        path,
        value: list,
      })
    } else if (type === 'edit'){
      const listIndex = parseInt(_.get(this.$router, 'params.listIndex', {}));
      const path = `active_detail.module.${moduleIndex}.list.${listIndex}`
      this.props.onHandelChangeActiveDetailData({
        path,
        value: initData
      });
    }
    this.props.onSaveActive({ ...activeDetail, id}); 
    Taro.navigateBack();
  }

  addEvent = (type) => {
    const { customList } = this.state;
    let initItem = {};
    if(type === 'text') {
      initItem = {type: 'text', value:''}
    } else {
      initItem = {type: 'img', value:''}
    }
    customList.push(initItem);
    this.setState({
      customList,
    })
  }

  deleteEvent = (index) => {
    const { customList } = this.state;
    customList.splice(index, 1);
    this.setState({
      customList,
    })
  }

  // 更改图片和text
  changeModule = (option, index, e) => {
    const value = option === 'img' ? e : e.target.value;
    const { customList } = this.state;
    customList[index].value = value
    this.setState({
      customList
    })
  }

  render () {
    const { prefix='custom-picText' } = this.props;
    const { customList, customType, addText } = this.state;
    return (
      <View className={prefix}>
        <CardHeader
          title='自定义图文'
          color='#EB0911'
        />
        {
          customList && customList.length > 0 ? (
            customList.map((item, index) => {
              const { type, value } = item;
              return (
                <View key={index} className={`${prefix}-cust`}>
                  {
                    type === 'img' ? (
                      <View className={`${prefix}-cust-text`}>
                        <View className={`${prefix}-cust-text-top`}>
                          <Text>{`${customType[0]} ${index + 1}：`}</Text>
                          <View
                            className={`${prefix}-cust-text-icon`}
                            onClick={this.deleteEvent.bind(this, index)}
                          >
                            <MJIcon
                              type='hdlu_shanchu'
                              size={36}
                              color='black'
                            />
                          </View>
                        </View>
                        <View
                          className={`${prefix}-cust-text-picbox`}
                        >
                          <UploadImage
                            desc={1}
                            title='上传图片'
                            img={value}
                            onChangeImage={this.changeModule.bind(this, 'img', index)}
                          >
                          </UploadImage>
                        </View>
                      </View>
                    ) : (
                      <View key className={`${prefix}-cust-text`}>
                        <View className={`${prefix}-cust-text-top`}>
                          <Text>{`${customType[1]} ${index + 1}：`}</Text>
                          <View
                            className={`${prefix}-cust-text-icon`}
                            onClick={this.deleteEvent.bind(this, index)}
                          >
                            <MJIcon
                              type='hdlu_shanchu'
                              size={36}
                              color='black'
                            />
                          </View>
                        </View>
                        <Textarea
                          className={`${prefix}-cust-text-cont`}
                          placeholder='请填写内容......'
                          maxlength={-1}
                          placeholderClass={`${prefix}-cust-text-contp`}
                          value={value}
                          onInput={this.changeModule.bind(this, 'text', index)}
                        />
                      </View>
                    )
                  }
                </View>
              )
            })
          ) : null
        }
        <View className={`${prefix}-addbox`}>
          {
            addText.map((item, index) => {
              const { value, type } = item;
              return (
                <View
                  key={index}
                  className={`${prefix}-addbox-button`}
                  onClick={this.addEvent.bind(this, type)}
                >
                <MJIcon
                  type='hdlu_tianjia'
                  size={32}
                  color='#EB0911'
                />
                <Text className={`${prefix}-addbox-btntext`}>{value}</Text>
              </View>
              )
            })
          }
        </View>
        <View className={`${prefix}-buttonbox`}>
          <Button
            className={`${prefix}-button`}
            onClick={this.saveClick.bind(this)}
          >
            确定
          </Button>
        </View>
      </View>
     
    )
  }
}

export default CustomPicText
