import Taro, { Component } from '@tarojs/taro';
import { connect } from '@tarojs/redux';
import { View, Image, Text } from '@tarojs/components';
import _ from 'lodash'
import { MJIcon, ActivityItem, AddButton } from '../../components';
import { queryActivesInfo, deleteActive, logout } from '../../actions/actives';
import noneImg from '../../assets/image/kong.png';
import navigate from '../../utils/navigate';

import './index.scss';

const tabList = [
  {
    id: 0,
    name: '未发布',
  }, {
    id: 1,
    name: '未开始',
  }, {
    id: 2,
    name: '已结束',
  }
];
const pulishBtns = [
  {
    id: 0,
    text: '删除活动',
  },
  {
    id: 1,
    text: '编辑活动',
  },
]
const startBtns = [
  {
    id: 2,
    text: '待审核名单',
  },
  {
    id: 3,
    text: '已报名名单',
  },
  {
    id: 4,
    text: '签到名单',
  },
];
const endBtns = [
  // {
  //   id: 5,
  //   text: '活动数据',
  // },
  {
    id: 6,
    text: '参与者信息',
  }
];

@connect(({ actives, auth }) => ({
  activesData: _.get(actives, 'actives_data', {}),
  token : _.get(auth, 'token', ''),
  ptid : _.get(auth, 'agency_info.ptid', ''),
  headImg : _.get(auth, 'agency_info.head_img', ''),
  uid : _.get(auth, 'uid', ''),
}), (dispatch) => ({
  onActivesInfo (query) {
    dispatch(queryActivesInfo(query))
  },
}))

class Index extends Component {
    static defaultProps = {
      prefix: 'app-actives',
    }
    config = {
    navigationBarTitleText: '旅业活动',
    navigationBarBackgroundColor: '#FAFAFA',
  }

  constructor(props) {
    super(props);
    this.state = {
      activeType: 1,
      firstMount: true
    };
    this.submitOn = true;
  }
  componentWillReceiveProps () {
  }
  componentWillMount() {
    this.props.onActivesInfo({mode: 1});
  }
   // 获取活动数据
   getActiveData = (mode, flag=false) => {
    const query = {
      mode
    };
    if(!flag) {
      this.props.onActivesInfo(query);
    }
    this.getActiveListLoop = setInterval(() => {
      this.props.onActivesInfo(query);
    }, 10000)
  }
  
  componentDidShow () {
    const { firstMount } = this.state;
    if(firstMount) {
      this.setState({
        firstMount: false
      })
    }
    this.getActiveData(this.state.activeType, firstMount);
  }

  componentDidHide () {
    if (this.getActiveListLoop) {
      clearInterval(this.getActiveListLoop);
    }
   }


  componentWillUnmount () {
    if (this.getActiveListLoop) {
      clearInterval(this.getActiveListLoop);
    }
  }

  // 更改tabType 
  onchageTab = (type) => {
    this.setState({
      activeType: type,
    });
    if (this.getActiveListLoop) {
      clearInterval(this.getActiveListLoop);
      // this.props.onActivesInfo({mode: type});
    }
    this.getActiveData(type);
  }
  //获取当前活动list
  getCurTabTypeList = (list) => {

    let activeList = [];
    let rencentList = [];
   list.map((item) => {
     const { class: classType } = item;
     if(classType === 0) {
      activeList.push(item);
     } else if(classType === 1){
      rencentList.push(item);
     }
   })
    return {
      activeList,
      rencentList
    };
  }
 // 获取当前title
  getCurTitle = (activeType, classType) => {
    let title = '';
    if(activeType === 0){
      title = '未发布活动';
    } else if(activeType === 1 ) {
      title = classType === 0 ? '今日活动' : '近期活动'; 
    } else {
      title = '往期活动';
    }
    return title;
  }

  // 报名二维码
  getChangeSignUp = (active_id) => {
    navigate({
      page: 'registErCode',
      param: {
        active_id,
      }
    })
  }
  // 报名二维码
  getChangeSignIn = (active_id) => {
    const { token, uid, ptid } = this.props;
    navigate({
      page: 'checkErCode',
      param: {
        active_id,
        token,
        uid,
        ptid,
      }
    })
  }

  // 编辑活动
  getHandelEdit = (active_id) => {
    navigate({
      page: 'createAct',
      param: {
        activeId: active_id,
        type: 'edit'
      }
    })
  }

  //活动button事件
  intoContactsInfo = (active_id,examine_status,buttonId) => {
    const { activeType } = this.state;
    const curOperation = this.getButtonIntoPage(active_id,examine_status,buttonId, activeType);
    switch (curOperation) {
    case 'delete':
      this.getDeleteActive(active_id);
      break;
    case 'edit':
        this.getEditActive(active_id);
      break;
    case 'checkList':
      navigate({
        page: 'checkList',
        param: {
          active_id,
          activeType,
          contactsInfoClass: 'check'
        }
      })
      break;
    case 'regist':
      navigate({
        page: 'registList',
        param: {
          active_id,
          activeType,
          contactsInfoClass: 'regist'
        }
      })
      break;
    case 'setIn':
      navigate({
        page: 'setInList',
        param: {
          active_id,
          activeType,
          contactsInfoClass: 'setIn'
        }
      })
      break;
    case 'participantInfo':
      navigate({
        page: 'participantList',
        param: {
          active_id,
          activeType,
          examine_status,
          contactsInfoClass: 'participantInfo'
        }
      })
      break;
    default:
      break;
    }
  }
  // 判断button进入那个页面
  getButtonIntoPage = (active_id,examine_status,buttonId, activeType) => {
    let pageType = '';
    // 未发布
    if (activeType === 0) {
      if (buttonId === 0) {
        // 进行删除按钮操作
        pageType = 'delete';
      } else if(buttonId === 1) {
        // 进入编辑活动操作
        pageType = 'edit';
      }
    }
    // 未开始
    if(activeType === 1) {
      if (buttonId === 2 && examine_status === 1) {
        // 进行审核名单操作
        pageType = 'checkList';
      }
      if (buttonId === 4) {
        // 进行签到名单操作
        pageType = 'setIn';
      }
      if (buttonId === 3 && examine_status === 0) {
        // 进行已报名操作
        pageType = 'regist';
      }
    }
    // 已结束
    if (activeType === 2) {
      if (buttonId === 5) {
        // 进行活动数据操作
        pageType = 'activeData';

      } else if(buttonId === 6) {
        // 进入参与者信息操作
        pageType = 'participantInfo';
      }
    }
    return pageType;
  }

  // 删除活动
  getDeleteActive = (active_id) => {
    const { activeType } = this.state;
    Taro.showModal({
      confirmText: '删除',
      cancelText: '取消',
      cancelColor: '#272C33',
      confirmColor: '#EB0911',
      content: '  确定要删除该活动吗？',
      success: ({ confirm, cancel }) => {
        if (confirm) {
          deleteActive({id: active_id}).then(() => {
            // 获取新的数据
            if(this.getActiveListLoop) {
              clearInterval(this.getActiveListLoop)
            }
            this.getActiveData(activeType);
          })
        } else if (cancel) {
        }
      }
    })
  }

  // 编辑活动
  getEditActive = (active_id) => {
    navigate({
      page: 'createAct',
      param: {
        type: 'edit',
        activeId: active_id 
      }
    })
  }

  // 退出
  getLogout = () => {
    const uid = _.get(this.$router, 'params.uid', {});
    Taro.showModal({
      title: '',
      content: '确定要退出登录吗',
      confirmColor: '#0061F3',
      success: function(res){
        if(res.confirm){
          logout({uid}).then(() => {
            Taro.clearStorage();
            navigate({
              page: 'index',
              type: 'redirectTo',
            })
          })
        }
      }
      
    }) 
  }

  // 创建活动
  onAddActive = () => {
    navigate({
      page: 'createAct',
      param: {
        type: 'add'
      }
    })
  }
  // 进入活动详情
  handelGotoDetail = (activeId) => {
    const { token, uid, ptid } = this.props;
    navigate({
      page : 'webView',
      param: {
        id: 0,
        type: 'detail',
        token,
        uid,
        ptid,
        activeId
      },
    });
  }

  render () {
    const { prefix = 'app-actives', activesData, headImg } = this.props;
    const { activeType } = this.state;
    const { list = [] } = activesData;
    return (
      <View className={prefix}>
        <View className={`${prefix}-header`}>
          <View className={`${prefix}-header-image`}>
            <Image
              style='height: 360rpx; width: 100%;'
              src={headImg}
            />
          </View>
          <View className={`${prefix}-header-logout`} onClick={this.getLogout.bind(this)}>
            <MJIcon
              type='hdlu_tuichu'
              size={50}
              color='#FFFFFF'
              className={`${prefix}-header-logout-icon`}
            >
            </MJIcon>
          </View>
          <View className={`${prefix}-header-tab`}>
              {
                tabList.map((item) => {
                  const { id, name } = item;
                  return (
                    <View className={`${prefix}-header-tab-content-item`} onClick={this.onchageTab.bind(this, id)} key={id}>
                      <View className={`${prefix}-header-tab-content-item ${activeType === id ? 'curItem' : ''}`}>{name}</View>
                      <View className={`${activeType === id ? 'curIcon' : ''}`}></View>
                    </View>
                  )
                })
              }
          </View>
        </View>
          {
            list && list.length > 0 ? (
              <View className={`${prefix}-content`}>
                {
                  list.map((item, index) => {
                    const { active_id, verify, verify_list_stat} = item;
                    return (
                        <ActivityItem
                          key={index}
                          data={item}
                          showdetail={activeType === 1}
                          examineStatus={verify}
                          btnList={activeType === 0 ? pulishBtns : activeType === 2 ? endBtns : startBtns}
                          activeType={activeType}
                          verifyliststat={verify_list_stat}
                          onIntoContactsInfo={this.intoContactsInfo.bind(this, active_id, verify)}
                          onChangeSignUp={this.getChangeSignUp.bind(this)}
                          onChangeSignIn={this.getChangeSignIn.bind(this)}
                          onHandelEdit={this.getHandelEdit.bind(this)}
                          onGotoDetail={this.handelGotoDetail.bind(this)}
                        >/</ActivityItem>
                    )
                  })
                }
             </View>
            ) : (
              <View className={`${prefix}-kong`}>
                <Image src={noneImg} className={`${prefix}-kong-img`} />
                <Text className={`${prefix}-kong-text`}>暂无活动</Text>
              </View>
            )
          }
        <View className={`${prefix}-btn`}>
          <AddButton
            title='新建'
            type='circle'
            color='#fff'
            onAddActive={this.onAddActive.bind(this)}
          />
        </View>
      </View>
     
    )
  }
}

export default Index
