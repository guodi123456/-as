import Taro, { Component } from '@tarojs/taro';
import { connect } from '@tarojs/redux';
import { View, Text} from '@tarojs/components';
import _ from 'lodash';
import { MJInput, CardHeader } from '../../components';
import { formatPeopleInfo } from '../../utils';
import { requestPeopleInfo } from "../../actions/actives";
import './index.scss';

const statusList = ['待审核', '待出席', '已签到', '已出席', '未出席', '审核未通过',  '签到未授权', '签到地点异常'];

@connect(({ actives }) => ({
  peopleInfo: _.get(actives, 'people_info', {})
}), (dispatch) => ({
  onRequestPeopleInfo(query) {
    dispatch(requestPeopleInfo(query))
  }
}))
class AddGuest extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }
  static defaultProps = {
    prefix: 'people-detail',
  }
  config = {
    navigationBarTitleText: '参会者信息'
  }
  componentDidMount = () => {
    const params = _.get(this.$router, 'params', {});
    this.props.onRequestPeopleInfo({
      csuid: params.csuid,
      id: params.id
    })
  }

  getTagType = (status) => {
    const list = [[0, 1], [2, 3], [6, 7], [4, 5]];
    let type = 0;
    list.some((item, index) => {
      if(item.includes(status)) {
        type = index;
        return true;
      }
    })
    return type;
   }

  render () {
    const { prefix='people-detail', peopleInfo } = this.props;
    const { content, status } = peopleInfo;
    const list = formatPeopleInfo(content)
    const tagType = this.getTagType(status)
    
    return (
      <View className={prefix}>
        <View className={`${prefix}-title`}>
          <CardHeader
            title='个人信息'
            tip={statusList[status]}
            color='rgba(235, 9, 17, 1)'
            tagType={tagType}
          />
        </View>
        {
          list[1] ?
          <View className={`${prefix}-cont`}>
            <MJInput
              show
              required
              label='姓名'
              onInputChange={this.nameChange.bind(this)}
              disabled
              value={list[1]}
              className={`${prefix}-matop`}
            />
          </View> : null
        }
        {
          list[2] ? 
          <View className={`${prefix}-cont`}>
            <MJInput
              show
              required
              label='手机号'
              onInputChange={this.nameChange.bind(this)}
              disabled
              value={list[2]}
              className={`${prefix}-matop`}
            />
          </View> : null
          }        
        {
          list[7] ? 
          <View className={`${prefix}-cont`}>
            <MJInput
              show
              required
              label='所在城市'
              onInputChange={this.nameChange.bind(this)}
              disabled
              value={list[7]}
            />
          </View> : null
        }
        {
          list[3] ? 
          <View className={`${prefix}-cont`}>
            <MJInput
              show
              required
              label='公司名称'
              onInputChange={this.nameChange.bind(this)}
              disabled
              value={list[3]}
            />
          </View> : null
        }
        {
          list[6] ? 
          <View className={`${prefix}-cont`}>
            <MJInput
              show
              required
              label='业务区域'
              onInputChange={this.nameChange.bind(this)}
              disabled
              value={list[6]}
            />
          </View> : null
        }
        {
          list[-1] ? 
          <View className={`${prefix}-jiudian`}>
            <View className={`${prefix}-jiudian-label`}>入住酒店详细地址</View>
            <MJInput
              onInputChange={this.nameChange.bind(this)}
              disabled
              value={list[-1]}
            />
          </View> : null
        }
        {
          list[4] ? 
          <View className={`${prefix}-cont`}>
            <MJInput
              show
              required
              label='职位'
              onInputChange={this.nameChange.bind(this)}
              disabled
              value={list[4]}
            />
          </View> : null
        }
        {
          list[5] ? 
          <View className={`${prefix}-cont`}>
            <MJInput
              show
              required
              label='邮箱'
              onInputChange={this.nameChange.bind(this)}
              disabled
              value={list[5]}
            />
          </View> : null
        }
      </View>
     
    )
  }
}

export default AddGuest
