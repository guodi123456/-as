export const SAVE_AUTH = 'SAVE_AUTH';
export const GETLOGO_INFO = 'GETLOGO_INFO';