'use strict';

/**
 * 环境变量
 * 默认development 发包的时候修改掉 确保调试时不产生报警
 */

var env = 'development';
// const env = 'test';
// const env = 'production';
// const env = 'pre1';
// const env = 'pre2';
const urlEnv = {
  development: {
    baseApi: "http://at.mioji.com/api/",
    suggApi: 'http://storetest.mioji.com/sugg/',
    baseUrl: "https://at.mioji.com",
    pingBak: 'https://at.mioji.com/pingbak'
  },
  test: {
    baseApi: "https://at.mioji.com/api/",
    suggApi: 'http://storetest.mioji.com/sugg/',
    baseUrl: "https://at.mioji.com",
    pingBak: 'https://at.mioji.com/pingbak'
  },
  production: {
    baseApi: "https://active.mioji.com/api/",
    suggApi: `https://store.mioji.com/api/sugg/`,
    baseUrl: "https://active.mioji.com",
    pingBak: 'https://active.mioji.com/pingbak'
  },
  // pre1: {
  //   php: 'https://pre1s.mioji.com/api',
  // },
  // pre2: {
  //   php: 'https://pre2s.mioji.com/api',
  // }
};

export default {
  env: urlEnv[env],
  ptid: "0001",
  appver: 100,
  dmo: '旅业活动',
  app: 'lvyouju_ACT',
};
