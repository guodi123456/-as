import _ from 'lodash';
import {
  GETACTIVES_INFO,
  GETCONTACT_INFO,
  GETACTIVE_DETAIL,
  GETINIT_DETAIL,
  CHANGEACTIVE_DETAILDATA,
  GETCOMMON_CITYS,
  GET_PEOPLEINFO,
  CHANGEACTIVE_LABELILDATA,
  GET_LABELILACTIVES,
  GETACTIVE_ID,
} from '../constants/actives';

const INITIAL_STATE = {
  active_detail: {
    base_info: {
      img: '',
      title:'',
      address: {
        city_name: '',
        name: '',
        coord: '',
        detail: ''
      },
      desc: '',
      end_date: '',
      end_time: '',
      entered_date: '',
      img: '',
      remind: '',
      sponsor: '',
      start_date: '',
      start_time: '',
      title: '',
    },
    flow: [
    ],
    module: [
    ],
    enter_info: {},
    id: ''
  },
  contact_data: []
}

export default function actives (state = INITIAL_STATE, action) {
  switch (action.type) {
    case GETACTIVES_INFO:
      return {
        ...state,
        actives_data: action.res
      }
    case GETCONTACT_INFO:
      return {
        ...state,
        contact_data: action.res
      }
    case GETINIT_DETAIL:
      return {
        ...INITIAL_STATE,
      }
    
    case GETACTIVE_DETAIL:
      return {
        active_detail: action.res,
      }
    case CHANGEACTIVE_DETAILDATA:
      const { path, value } = action.res;
      if (path && path.length) {
        _.set(state, path, value);
      }
      return _.cloneDeep(state);
    case GETCOMMON_CITYS: 
      return {
        ...state,
        common_citys: action.res,
      }
    case GET_PEOPLEINFO: 
      return {
        ...state,
        people_info: action.res
      }
    case CHANGEACTIVE_LABELILDATA: 
      const { url, data } = action.res;
      if (url && url.length) {
        _.set(state, url, data);
      }
    case GET_LABELILACTIVES: 
      return {
        ...state,
        actives_Alllabels: action.res
      }
    case GETACTIVE_ID:
      let newSate = {};
      let newActive_detail = {};
      Object.assign(newActive_detail, state.active_detail, action.res);
      Object.assign(newSate, state, {active_detail: newActive_detail});
      return {
        ...newSate
      }
    default:
      return state
  }
}
