import { combineReducers } from 'redux'
import actives from './actives'
import auth from './logoin'

export default combineReducers({
  actives,
  auth,
})
