import { GETLOGO_INFO } from '../constants/login'

const INITIAL_STATE = {
}

export default function counter (state = INITIAL_STATE, action) {
  switch (action.type) {
    case GETLOGO_INFO:
      return {
        ...state,
        ...action.res
      }
     default:
       return state
  }
}
