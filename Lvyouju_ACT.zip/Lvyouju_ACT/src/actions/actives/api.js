import Taro from '@tarojs/taro';
import _ from 'lodash';
import request from '../../utils/request';
import {
  GETACTIVES_INFO,
  GETCONTACT_INFO,
  GETACTIVE_DETAIL,
  GETINIT_DETAIL,
  CHANGEACTIVE_DETAILDATA,
  GETCOMMON_CITYS,
  GET_PEOPLEINFO,
  CHANGEACTIVE_LABELILDATA,
  GET_LABELILACTIVES,
  GETACTIVE_ID
} from '../../constants/actives';
import { replacePeopleList } from '../../utils';
import { on } from 'cluster';


// 获取活动列表action
export const getActivesInfo = (res) => {
  return {
    type: GETACTIVES_INFO,
    res
  }
}

// 获取活动联系人action
export const getContactInfo = (res) => {
  return {
    type: GETCONTACT_INFO,
    res
  }
}

// init活动
export const getInitDetail = (res) => {
  return {
    type: GETINIT_DETAIL,
    res
  }
}
// 获取活动详情action
export const getActiveAction = (res) => {
  return {
    type: GETACTIVE_DETAIL,
    res
  }
}

// 获取人员详情资料
export const getPeopleInfo = (res) => {
  return {
    type: GET_PEOPLEINFO,
    res
  }
}

// 更改活动详情action
export const changeActiveDetailData = (res) => {
  return {
    type: CHANGEACTIVE_DETAILDATA,
    res
  }
}

// 添加活动label
export const changeActiveLabelData = (res) =>{
  return {
    type: CHANGEACTIVE_LABELILDATA,
    res
  }
}

// 获取活动label
export const changeActiveAllLabelData = (res) => {
  return {
    type: GET_LABELILACTIVES,
    res
  }
}

// 获取常用城市action
 export const getCommonCities = (res) => {
   return {
     type: GETCOMMON_CITYS,
     res
   }
 }
// 获取常用城市action
 export const getActiveId = (res) => {
   return {
     type: GETACTIVE_ID,
     res
   }
 }

// 获取活动列表信息
export function queryActivesInfo (query = {}) {
  return (dispatch) => {
    const promise = request({
      type: 'api45709',
      query,
    });
    promise && promise.then((res) => {
      const data = _.get(res, 'data.data');
      dispatch(getActivesInfo(data));
      Taro.hideLoading();
    });
    return promise
  }
}

// 获取人员信息
export function requestPeopleInfo (query = {}) {
  return (dispatch) => {
    const promise = request({
      type: 'api45713',
      query
    });
    promise && promise.then((res) => {
      const data = _.get(res, 'data.data');
      dispatch(getPeopleInfo(data));
      Taro.hideLoading();
    });
    return promise
  }
}

// 退出登录
export const logout = (query) => {
  return request({
    type: 'api45701',
    query,
  });
}


// 删除活动
export const deleteActive = (query) => {
  return request({
    type: 'api45710',
    query,
  });
}

// 获取审核名单
export function requestContactInfo (query = {}, flag = false) {
  return (dispatch) => {
    const promise = request({
      type: 'api45711',
      query,
    });
    promise && promise.then((res) => {
      const data = _.get(res, 'data.data');
      data.list = flag ? replacePeopleList(data.list) : data.list;     
      dispatch(getContactInfo(data.list));
    });
    return promise
  }
}

// 获取活动详情
export function requestActiveDetail(query = {}) {
  return (dispatch) => {
    const promise = request({
      type: 'api45704',
      query,
    });
    promise && promise.then((res) => {
      const data = _.get(res, 'data.data');
      dispatch(getActiveAction(data));
      
    });
    return promise;
  }
}

// 更改活动详情信息
export const handelChangeActiveDetailData = (res) => {
  return (dispatch) => {
    dispatch (changeActiveDetailData(res))
  }
}

// 设置活动自定义信息
export function getActiveLabels(res) {
  return (dispatch) => {
    dispatch (changeActiveLabelData(res))
  }
}

// 
export function getActiveAllLabels (res) {
  return (dispatch) => {
    dispatch (changeActiveAllLabelData(res))
  }
}

// 获取常用城市
export function requestCommonCities(query = {}) {
  return (dispatch) => {
    const promise = request({
      type: 'api45714',
      query,
    });
    promise && promise.then((res) => {
      const data = _.get(res, 'data.data');
      dispatch(getCommonCities(data));
    });
    return promise;
  }
}


/**
 * suggestion请求
 */
export const getSuggestion = (query) => {
  return request({
    type: 'g203',
    query,
    method: 'GET',
  })
};


// 保存活动
export function saveActive(query = {}) {
  return (dispatch) => {
    const promise = request({
      type: 'api45702',
      query,
    });
    promise && promise.then((res) => {
      const data = _.get(res, 'data.data');
      if (data.id) {
        dispatch(getActiveId(data));
      }
    });
    return promise;
  }
}
// 生成二维码
export const getErweima = (query) => {
  return request({
    type: 'api45705',
    mock: 'on',
    query,
  });
}

