import Taro from '@tarojs/taro'
import request from '../utils/request';
import { GETLOGO_INFO } from '../constants/login'
import navigate from '../utils/navigate';


export const getLogoInfo = (res) => {
	return {
		type: GETLOGO_INFO,
		res
	}
}

// 用户登录
export const doLogin = (query) => {
    return (dispatch) => {
			const promise = request({
				type: 'api45700',
				query,
			});
			promise.then((res) => {
				const data = (res && res.data.data) || {};
				// 登录状态校验
				const { stat, uid, agency_info } = data;
				const { ptid } = agency_info;
				// 正常登录
				if (stat === 0) {
					dispatch(getLogoInfo(data))
					Taro.setStorageSync('userInfo', data);
					navigate({
						page: 'actives',
						type: 'redirectTo',
						param: {
							uid,
							ptid,
						}
					})
				} else {
					dispatch(getLogoInfo(data))
				} 
				
			})
			.catch((err) => {
				Taro.showToast({
				title: '登录失败',
				icon: 'none',
				duration: 2000
			})
			console.log('登录失败', err);
		})
	}
}

// 用户信息存储
export function setAuth (res) {
  return (dispatch) => {
    dispatch (getLogoInfo(res))
  }
}