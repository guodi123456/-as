import '@tarojs/async-await'
import Taro, { Component } from '@tarojs/taro'
import { Provider } from '@tarojs/redux'
// 引入taro UI的全局样式
import 'taro-ui/dist/style/index.scss'

import Index from './pages/index'

import configStore from './store'

import './app.scss'

// 如果需要在 h5 环境中开启 React Devtools
// 取消以下注释：
// if (process.env.NODE_ENV !== 'production' && process.env.TARO_ENV === 'h5')  {
//   require('nerv-devtools')
// }

const store = configStore()

class App extends Component {

  config = {
    pages: [
      'pages/index/index',
      'pages/checkList/index',
      'pages/registList/index',
      'pages/setInList/index',
      'pages/participantList/index',
      'pages/createAct/index',
      'pages/registAct/index',
      'pages/checkInAct/index',
      'pages/actives/index',
      'pages/choiceLocation/index',
      'pages/addProcess/index',
      'pages/addCustom/index',
      'pages/addGuest/index',
      'pages/peopleDetail/index',
      'pages/webView/index',
      'pages/customPicText/index',
      'pages/addContacts/index',
      'pages/downloadInfo/index',
      'pages/addInformation/index',
    ],
    window: {
      backgroundTextStyle: 'light',
      navigationBarBackgroundColor: '#fff',
      navigationBarTitleText: 'WeChat',
      navigationBarTextStyle: 'black'
    },
    permission: {
    "scope.userLocation": {
      "desc": "你的位置信息将用于小程序位置接口的效果展示"
    }
  }

}

  componentDidMount () {}

  componentDidShow () {}

  componentDidHide () {}

  componentCatchError () {}

  componentDidCatchError () {}

  // 在 App 类中的 render() 函数没有实际作用
  // 请勿修改此函数
  render () {
    return (
      <Provider store={store}>
        <Index />
      </Provider>
    )
  }
}

Taro.render(<App />, document.getElementById('app'))
