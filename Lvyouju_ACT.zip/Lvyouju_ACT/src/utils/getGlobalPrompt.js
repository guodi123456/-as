const getGlobalPrompt = (errorId) => {
  let text = '';
  switch (errorId) {
    case 210003:
        text = '账号在另一台设备登录，请重新登录'
      break;
    case 210006:
        text = '账号已被删除，请重新登录'
      break;
    case 210007:
        text = '密码已被重置，请重新登录'
      break;
    case 210008:
        text = '账号已被禁用，请重新登录'
      break;
    default:
      break;
  }
  return text;
}

export default getGlobalPrompt;