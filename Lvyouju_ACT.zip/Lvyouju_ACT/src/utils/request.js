import Taro from '@tarojs/taro';
import _ from 'lodash';
import { getComParams } from './index';
import config from '../config';
import getGlobalPrompt from './getGlobalPrompt';
import navigate from './navigate';

const { env: { baseApi, suggApi } } = config

const formatUrl = (type, qid, mock) => {
	let url = '';
    if (mock === 'on') {
        return `http://yapi.demo.qunar.com/mock/7606/${type}`;
    }
		const ppm = getComParams();
		if (type === 'g203') {
			url = `${suggApi}common/global?type=${type}&qid=${qid}&${ppm}}`
		}else {
			url = `${baseApi}?type=${type}&qid=${qid}&${ppm}`
		}
    return url
}

const request = (
    {
        type,
        query = {},
        method = 'POST',
        mock = '',
        header = {}
    }
) => {
    const qid = Date.now();
    const userInfo = Taro.getStorageSync('userInfo');
		const miojitoken = userInfo && userInfo.token;
    const reqPromise = new Promise((resolve, reject) => {
			// Taro.showLoading({
			// 	title: 'loading',
			// });
			Taro.request({
					url: formatUrl(type, qid, mock),
					data: {
						"query": query,
						"v": "1.0.0"
					},
					method: method,
					mode: 'cors',
					header: {
							'content-type': mock === 'on' ? 'application/json' : 'application/json',
							miojitoken,
							...header
					},
					success: (data) => {
							const  errorId = _.get(data, 'data.error.error_id');
							// 热更新
							if ([100].includes(errorId, 0)) {
									Taro.redirectTo({
											url: `/pages/update/index`
										});
										return;
							}
							if (errorId !== 0) {
								Taro.showModal({
									content: getGlobalPrompt(errorId),
									confirmText: '知道了',
									cancelText: '',
									confirmColor: '#0061F3',
									success: ({ confirm }) => {
										if(confirm) {
											navigate({
												type: 'redirectTo',
												page: 'index'
											});
											Taro.hideLoading();
											Taro.clearStorage();
										}
									} 
								});
								reject(data);
								Taro.hideLoading();
								return;
							}
							resolve(data);
							Taro.hideLoading();
					},
					fail: (err) => {
						reject(err);
						Taro.hideLoading();
					}
			});
    });
    return reqPromise;
}
export default request