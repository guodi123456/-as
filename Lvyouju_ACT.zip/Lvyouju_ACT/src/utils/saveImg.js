import Taro from '@tarojs/taro';

const getSetting = () => {
  return new Promise((resolve) => {
    Taro.getSetting({
      success: res => {
        resolve(res)
      }
    })
  })
}

const authorize = () => {
  return new Promise((resolve, reject) => {
    Taro.authorize({
      scope: 'scope.writePhotosAlbum',
      success: () => {
        resolve()
      },
      fail: () => { //这里是用户拒绝授权后的回调
        console.log('拒绝授权')
        reject()
      }
    })
  })
}

const saveImageToPhotosAlbum = (saveUrl) => {
  return new Promise((resolve) => {
    Taro.showLoading({
      title: '正在保存...'
    })
    Taro.saveImageToPhotosAlbum({
      filePath: saveUrl,
      success: () => {
        Taro.hideLoading();
        Taro.showToast({
          title: '保存成功',
          duration: 1000,
        })
        resolve()
      }
    })
  })
}

const downLoadFile = (img) => {
  return new Promise((resolve) => {
    Taro.downloadFile({
      url: img,
      success: (res) => {
        console.log('downloadfile', res)
        resolve(res)
      }
    })
  })
}

const savedownloadFile = (img) => {
  Taro.showModal({
    content: '确认保存？',
  })
    .then(model => {
      if(model.confirm) {
        downLoadFile(img).then((res) => {
          return saveImageToPhotosAlbum(res.tempFilePath)
        }).then(() => {      
        })
      }
    })
}

export {
  getSetting,
  authorize,
  savedownloadFile,
  downLoadFile,
  saveImageToPhotosAlbum
}