import Taro from '@tarojs/taro'
import config from '../config'
import navigate from '../utils/navigate'
import request from './request'

const { ptid, app, appver } = config;

export const getComParams = (uid) => {
  const userInfo = Taro.getStorageSync('userInfo') || '';
  uid = uid || userInfo && userInfo.uid;
  const Ptid = userInfo && userInfo.agency_info.ptid || '';
  return `ptid=${Ptid || ptid}&uid=${uid}&appver=${appver}&app=${app}`;
}

// 格式审核列表数组
export const replacePeopleList = (people_list) => {
  const _list1 = [];
  const _list2 = [];
  if (people_list && people_list.length) {
    people_list.forEach((item) => {
      const { look } = item;
      if(look === 0) {
        _list1.push(item);
      }else {
        _list2.push(item);
      }
    })
    return [[..._list1], [..._list2]];
  }
}

// 跳转到人员详情
export const navigatoDetail = (csuid, id) => {
  navigate({
    page: 'peopleDetail',
    param: {
      id,
      csuid,
    }
  })
}

export const searchPeopleList = async (id, mode, val, status) => {
  const res = await request({
    type: 'api45711',
    query: {
      id,
      mode,
      status, 
      filter: {
        key: val
      }
    }
  })
  console.log(res);
  
  return res;
}
// 格式人员信息
export const formatPeopleInfo = (data=[]) => {
  const obj = {};
  data.length && data.forEach((item) => {
    obj[item.ktype] = item.key;
  })
  return obj;
}