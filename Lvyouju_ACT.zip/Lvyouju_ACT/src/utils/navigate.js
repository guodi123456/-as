import Taro from '@tarojs/taro';
import router from './router';


export const noop = () => {};

const navigate = ({
    type = 'navigateTo',
    page,
    param = {},
    successFn = noop,
    failFn = noop,
    completeFn = noop,
  }) => {
    const paramKeys = Object.keys(param);
    const paramUrl = paramKeys.map(item => `${item}=${param[item]}`).join('&');
    Taro[type]({
      url: `${router[page]}${paramUrl ? `?${paramUrl}` : ''}`,
      success: successFn,
      fail: failFn,
      complete: completeFn,
    });
  }
export default navigate