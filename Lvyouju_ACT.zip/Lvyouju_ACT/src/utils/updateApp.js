
const updateApp = () => {
  if (wx.canIUse('getUpdateManager')) {
    const updateManager = wx.getUpdateManager()
    updateManager.onCheckForUpdate((res)=> {
      // 请求完新版本信息的回调
      console.log(res.hasUpdate)
    })
    updateManager.onUpdateReady(() => {
      updateManager.applyUpdate()
    })
    updateManager.onUpdateFailed(() => {
      wx.showModal({
        //title: '有新版小程序',
        content: '新版本已经准备好，需要删除当前小程序重新进入',
      })
    });
  } else {
    wx.showModal({
      title: '提示',
      content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
    });
  }
}

export default updateApp
