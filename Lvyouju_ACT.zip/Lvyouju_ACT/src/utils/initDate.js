/**
 * 将 2019-03-04 10:12 转换成 20190304 or 10:12 等
 * @param {*} str 非8位时间字符串 2019-03-04 10:12
 * @param {*} needDate 是否返回日期
 * @param {*} needTime 是否返回时间
 */
const initDate= () => {
  const date=new Date();
	  //年
    const year=date.getFullYear();
    //月
    const month=date.getMonth()+1;
    //日
    const day=date.getDate();
    //时
    const rq = `${year}-${month.length === 2 ? month : `0${month}`}-${day.length === 2 ? day : `0${day}`}`;
    return rq;
 
}
export default initDate;



