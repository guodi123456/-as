/**
 * 将 20190304 转换成 2019年3月4日 or 2019-03-04 等
 * @param {*} str 8位时间字符串 2019-03-04
 * @param {*} format 字符串或数组均可 '.' or '-' or ['年', '月', '日']
 * @param {*} needYear 是否展示年限
 * @param {*} needZero 是否需要补零
 */
const dateFormater = (str, format = '.', needYear = true, needZero = false,) => {
  if (!String(str) ||  !str) return;
  if (str.length === 10 ) {
    str = str.split("-").join("")
  }
  const [year, month = year, date = year] = [].concat(format);
  return `${needYear ? `${str.slice(0, 4)}${year}` : ''}${
    needZero ? str.slice(4, 6) : parseInt(str.slice(4, 6), 10)}${month}${
    needZero ? str.slice(6, 8) : parseInt(str.slice(6, 8), 10)}${date === '日' ? date : ''}`
}
export default dateFormater;


