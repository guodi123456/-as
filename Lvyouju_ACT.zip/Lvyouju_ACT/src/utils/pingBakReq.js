import config from '../config'
import store from '../store'

const { dispatch } = store;
const { ptid } = config;

// pingBak
// action ==> pingbak类型  START | SUCCESS | FAIL
// type ==> api接口类型
// result ==> 请求返回的结果
export default (action, type, csuid, qid, result) => {
  const pbData = {
    csuid,
    type,
    qid,
    ptid,
  }
  dispatch({
    type: `REQUSET_DEFAULT_${action}`,
    request_query: pbData,
    result
  })
}