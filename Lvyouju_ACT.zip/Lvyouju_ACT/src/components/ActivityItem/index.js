import Taro, { Component } from '@tarojs/taro'
import { View, Image, Text } from '@tarojs/components'
import moment from 'moment';
import ActiveButton from '../ActiveButton'
import dateFormater  from '../../utils/formatDate';

import './index.scss'

const formate = [ '年', '月', '日'];

class ActivityItem extends Component {

  static defaultProps = {
    prefix: 'com-activityitem',
    data: {}
  }
  constructor(props) {
    super(props);
    this.state = {
      signInBtnShow: false
    };
  }

  componentDidMount () {
    const { data } = this.props;
    const { start_date, start_time } = data;
    this.signInBtnShow(start_date, start_time);
  }
  // 获取今天是星期几
  getWeekDay =(start_date) => {
    const weekDay = ["星期天", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
    var myDate = new Date(start_date);
    return weekDay[myDate.getDay()]
  }

  //进入详情页
  gotoDetail = (active_id) => {
    const { onGotoDetail } = this.props;
    if (onGotoDetail){
      onGotoDetail(active_id);
    }
  }
  // 签到名单按钮展示
  signInBtnShow = (start_date,start_time) => {
    const startTime = moment(`${start_date} ${start_time}`);
    const curTime = moment(moment().format('YYYY-MM-DD HH:mm'));
    if (startTime.diff(curTime, 'days') <= 2 ) {
      this.setState({
        signInBtnShow: true
      })
    }
  }
  //获取时间展示文案
  getTime = (start_date, end_date, start_time, end_time) => {
    let text = '';
    if(end_date !== start_date ) {
      text = `${dateFormater(start_date, formate, false, true)} ${start_time} - ${
        dateFormater(end_date, formate, false, true)} ${end_time}`
    } else {
      text = `${dateFormater(start_date, formate, false, true)} ${this.getWeekDay(start_date)} ${start_time} - ${end_time}`
    }
    return text;
  }

  render () {
    const prefix = 'com-activityitem'
    const {
      data,
      showdetail,
      btnList,
      activeType,
      examineStatus,
      onChangeSignUp,
      onChangeSignIn,
      onIntoContactsInfo,
      onHandelEdit,
      verifyliststat,
    } = this.props;
    const { img, title, start_date, end_date, start_time, end_time, address = {}, sponsor, active_id } = data;
    const {
      city_name,
      name,
    } = address;
    const { signInBtnShow } = this.state;
    return (
      <View className={prefix}> 
          <View className={`${prefix}-info`} onClick={this.gotoDetail.bind(this, active_id)}>
            <Image 
              className={`${prefix}-info-image`} 
              src={img}
              mode='aspectFill'
            />
          <View className={`${prefix}-info-detail`}>
            <View className={`${prefix}-info-detail-host`}>
              <Text>{ `${sponsor}主办` || '主办方' }</Text>
            </View>
            <View className={`${prefix}-info-detail-title`}>
            <Text>{ title || '活动名称' }</Text>
            </View>
            <View className={`${prefix}-info-detail-time`}>
            <Text>
              {
                start_date && end_date ? this.getTime(start_date, end_date, start_time, end_time): '活动时间'
              }
            </Text>
            </View>
            <View className={`${prefix}-info-detail-local`}>
                <Text>{`${city_name || '城市'} | ${name || '活动地点'}`}</Text>
            </View>
          </View>
      </View>
        <ActiveButton
          showdetail={showdetail}
          activeId={active_id}
          verifyliststat={verifyliststat}
          btnList={btnList}
          signInBtnShow={signInBtnShow}
          activeType={activeType}
          examineStatus={examineStatus}
          onChangeSignUp={onChangeSignUp}
          onChangeSignIn={onChangeSignIn}
          onHandelEdit={onHandelEdit}
          onIntoContactsInfo={onIntoContactsInfo}
        ></ActiveButton>
      </View>

    )
  }
}

export default ActivityItem