import Taro, { Component } from '@tarojs/taro';
import { View, Text, Picker } from '@tarojs/components';
import dayJs from 'dayjs';
import MJIcon from '../MJIcon';

import './index.scss'

class Select extends Component {

  static defaultProps = {
    prefixCls: 'mj-select',
    borderBAll: false,
    type: 'date',
    isRequired: false,
    iconInEnd: false,
  };

  state = {
    dtValue: ''
  }
  componentDidMount = () => {
    this.initValue();
  }

  onChange = e => {
  }

  initValue = () => {
    const { type } = this.props;
    if(!['date', 'time'].includes(type)) return;
    let val = +new Date();
    const new_val = type === 'date' ? dayJs(val).format('YYYY年MM月DD日') : dayJs(val).format('HH:mm')
    this.setState({
      dtValue: new_val
    })
  }

  render () {
    const {
      prefixCls,
      label,
      borderBAll,
      type,
      isRequired,
      width,
      list,
      value,
      iconInEnd,
      otherLabel
    } = this.props;
    const {dtValue} = this.state;
    const iconEndC = iconInEnd ? `${prefixCls}-iconend` : '';
    return (
      <View className={`${prefixCls} ${borderBAll ? 'mjselect-bot' : ''}`} style={{width}}>
        {
          label ?
          <Text className={`${prefixCls}-label`}>
            {label}
            { 
              isRequired ? <Text className={`${prefixCls}-label-reqi`}>*</Text> : null
            } 
          </Text> : null
        }
        <View className={`${prefixCls}-content ${borderBAll ? '' : 'mjselect-bot'}`}>
          {
            otherLabel ? <Text className={`${prefixCls}-contTitle`}>{otherLabel}</Text> : null
          }
          <Picker
            className={`${prefixCls}-picker ${iconEndC}`}
            mode={type}
            range={list}
            onChange={this.onChange}
          >
            <View className={`${prefixCls}-picker-text`}>
              {value ? value : dtValue}
            </View>
          </Picker>
          <MJIcon
            type='hdlu_zhankai'
            size={46}
            color='red'
          />
        </View>
      </View>
    );
  }
}

export default Select;