import Taro, { Component } from '@tarojs/taro';
import { View, Input } from '@tarojs/components';
import { connect } from '@tarojs/redux';
import { getSuggestion } from '../../actions/actives'
import { MJIcon } from '../index';
import './index.scss'

/*
 * @params
 *   checked  是否打开
 *   onChangeSw 获取状态事件
 */

// @connect(({ }) => ({
// }), (dispatch) => ({
// }))
class Suggestion extends Component {
  static defaultProps = {
    prefixCls: 'mj-suggestion',
  }

  constructor(props) {
    super(props)
    this.state = {
      city_list:[]
    }
  }

  handelChange  = (e) => {
    const key = e.target.value;
    getSuggestion({
      data: 3,
      match: 3,
      num: 50,
      key,
    }).then((res) => {
      const city_list = res.data.data;
      this.setState({
        city_list
      })
    });
  }

  handleSelect = (item) => {
    const { onSelect } = this.props;
    if (onSelect) {
      onSelect(item)
    }
  }


  render() {
    const { prefixCls = 'mj-suggestion', placeholder } = this.props
    const { city_list } = this.state;
    return (
      <View className={`${prefixCls}`}>
        <View className={`${prefixCls}-citys`}>
          <View className={`${prefixCls}-citys-icon`}>
            <MJIcon 
              type='hdlu_sousuo'
              size={36}
              color='#c0c5cc'
            />
          </View>
          <Input
            className={`${prefixCls}-citys-input`}
            placeholder={placeholder}
            placeholderClass={`${prefixCls}-citys-placeholder`}
            onInput={this.handelChange.bind(this)}
            //  onClick={this.handleClick}
          />
          {
            city_list && city_list .length > 0 ? (
              <View className={`${prefixCls}-citys-content`}>
                {
                  city_list.map((item, index) => {
                    const { name, name_en, country } = item;
                    return (
                      <View className={`${prefixCls}-citys-content-item`} key={index} onClick={this.handleSelect.bind(this, item)}>
                        <View className={`${prefixCls}-citys-content-item-icon`}>
                          <MJIcon 
                            type='hdlu_zuobiao'
                            size={36}
                            color='#545B66'
                          />
                        </View>
                        <View className={`${prefixCls}-citys-content-item-name`}>
                          {name || name_en}{country ? `, ${country}` : ''}
                        </View>
                      </View>
                    )
                  })
                }
              </View>
            ) : null
          }
        </View>      
      </View>
    )
  }
}

export default Suggestion