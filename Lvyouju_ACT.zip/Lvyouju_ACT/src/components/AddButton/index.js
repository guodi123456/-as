import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components'
import { MJIcon } from '../MJIcon'
import './index.scss'


class AddButton extends Component {
  static defaultProps = {
    prefix: 'com-addbutton',
    title:'新建',
    icon: true
  }
  // 点击事件
  handelClick = () => {
    const { onAddActive } = this.props;
    if(onAddActive) {
      onAddActive();
    }
  }
   
  render () {
    const { prefix = 'com-addbutton',title, type, color, icon, iconType, size, fontSize }=this.props;
    const prefixs = type === 'circle' ? `${prefix}Circle` : type === 'normal' ? `${prefix}Normal` : `${prefix}Confirm`;
    return (
      <View className={`${prefixs}`} onClick={this.handelClick.bind(this)} >
        <View className={`${prefixs}-add`}>
          {
            icon ? (
              <View className={`${prefixs}-add-icon`}>
                <MJIcon
                  type={iconType || 'hdlu_tianjia'}
                  size={size ? size : 28}
                  color={color}
                />
              </View>
            ) : null
          }
          <View className={`${prefixs}-add-text add-font${fontSize}`}>{title}</View> 
        </View>
      </View>
    )
  }
}

export default AddButton