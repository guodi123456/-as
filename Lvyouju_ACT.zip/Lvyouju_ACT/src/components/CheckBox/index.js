import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import { MJIcon } from '../MJIcon';
import './index.scss';


class CheckBox extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ifCheck: false
    }
  }
  static defaultProps = {
    prefix: 'com-mjcheck',
    text: '',
    disabled: false
  }

  handleClick = () => {
    const { onCheckChange, value, disabled } = this.props;
    if(disabled) return;
    const obj = {};
    const { ifCheck } = this.state;
    obj['val'] = ifCheck ? null : value;
    obj['uid'] = value;
    this.setState({
      ifCheck: !ifCheck
    })
    onCheckChange(obj);
  }

  // 监听props中checked是否发生改变
  componentWillReceiveProps = (newProps) => {
    if(this.props.checked !== newProps.checked) {
      this.setState({
        ifCheck: newProps.checked
      })
    }
  }

  

  // 首次同步checked打开状态
  componentDidMount = () => {
    const { checked } = this.props;
    checked && this.setState({
      ifCheck: this.props.checked
    })
  }

  render () {
    const { prefix = 'com-mjcheck', disabled } = this.props;
    const { ifCheck } = this.state;
    return (
      <View
        className={`${prefix} checkbg${disabled ? 2 : ifCheck ? 1 : 3} checkborder${disabled ? 2 : ifCheck ? 1 : 2}`}
        onClick={this.handleClick}
      >
        {
          ifCheck || disabled ?
          <MJIcon
            type='hdlu_yiwancheng'
            size={40}
            color='#fff'
          /> : null
        }
      </View>
    );
  }
}

export default CheckBox;
