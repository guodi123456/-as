export const iconTypes = [
  [{type: 'hdlu_bianji', color: 'black'}, {type: 'hdlu_shanchu', color: 'black'}],  // iconType === 0
  [{type: 'hdlu_xiayi', color: '#EB0911'}, {type: 'hdlu_shangyi', color: '#EB0911'}, '#C9CED6'], // iconType === 1
];

export default {
}
