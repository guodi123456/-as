import Taro, { Component } from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components'
import MJIcon from '../../components/MJIcon'
import { iconTypes } from './constants'
import './index.scss'

const noop = () => {}
class ActiveProcess extends Component {
  static defaultProps  = {
    prefixCls: 'mj-at-process',
    pointNum: '',
    startTime: '14:00',
    endTime: '14:30',
    iconType: 2,    // 2:无icon  0: 编辑、删除    1：上下箭头 
    content: '',
    subContent: [],
    isContact: false,
    tel: null,
    ifShowBorder: true,
    isFirst: false,
    isLast: false,
  }

  leftIconClick = () => {
    const { onLeftIconClick } = this.props;
    if (onLeftIconClick) {
      onLeftIconClick();
    }
  }

  rightIconClick = () => {
    const { onRightIconClick } = this.props;
    if (onRightIconClick) {
      onRightIconClick();
    }
  }
  render () {
    const {
      prefixCls,
      pointNum = 0,  // 序号
      startTime,
      endTime,
      iconType,
      content, // 一级内容
      subContent,  // 数组，二级内容
      headerImg, // 头像
      titleName, // 姓名
      tel,     // 联系人号码
      ifShowBorder, // 是否显示border-bottom
      isFirst,  // 上升箭头是否第一个
      isLast,   // 下降箭头是否最后一个
    } = this.props;
    const showBorderBot = ifShowBorder ? 'at_process_border' : '';
    const iconSFirst = iconType === 1 ? (isFirst ? 'iconTre' : 'iconsub') : '';
    const iconSLast = iconType === 1 ? (isLast ? 'iconTre' : 'iconsub') : '';

    return (
      <View className={`${prefixCls} ${pointNum ? '' : showBorderBot}`}>
        {
          pointNum ? 
          <View className={`${prefixCls}-point`}>
            <View className={`${prefixCls}-point-cont`}>{pointNum}</View>
          </View> : null
        }
        {
          headerImg ?
          <Image
            src={headerImg}
            className={`${prefixCls}-headerimg`}
          /> : null
        }
        <View className={`${prefixCls}-content ${pointNum ? showBorderBot : ''}`}>
          <View className={`${prefixCls}-content-top`}>
            <Text className={`${prefixCls}-content-time`}>
              {
                pointNum ?
                <Text>
                  {startTime}
                  <Text className={`${prefixCls}-content-time-line`}>‐</Text>
                  {endTime}
                </Text> :
                <Text>{tel ? '姓名：' : ''}{titleName}</Text>
              }
            </Text>
            {
              iconType === 2 ? 
              null : 
              <View className={`${prefixCls}-content-icons`}>
                <View className={`${prefixCls}-content-icon ${prefixCls}-content-${iconSLast}`}>
                  <MJIcon
                    type={iconTypes[iconType][0].type}
                    size={36}
                    color={isLast ? iconTypes[iconType][2] : iconTypes[iconType][0].color}
                    onClick={this.leftIconClick.bind(this)}
                  />
                </View>
                <View className={`${prefixCls}-content-icon ${prefixCls}-content-${iconSFirst}`}>
                  <MJIcon
                    type={iconTypes[iconType][1].type}
                    size={36}
                    color={isFirst ? iconTypes[iconType][2] : iconTypes[iconType][0].color}
                    onClick={this.rightIconClick.bind(this)}
                  />
                </View>
              </View>
            }
          </View>
          {
            tel ? 
            <Text className={`${prefixCls}-content-tel`}>
              联系方式：{tel}
            </Text> : 
            <Text className={`${prefixCls}-content-cont`}>
              {content}
            </Text>
          }
          {
            subContent.length ? 
            subContent.map((item, index) => {
              return <Text key={index} className={`${prefixCls}-content-subcont`}>{item}</Text>
            }) : null
          }
        </View>
      </View>
    )
  }
}

export default ActiveProcess