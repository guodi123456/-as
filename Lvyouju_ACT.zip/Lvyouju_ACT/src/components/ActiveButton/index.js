import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import { MJIcon } from '../../components';
import './index.scss'

class ActiveButton extends Component {
    static defaultProps = {
        prefix: 'com-activebutton',
      }

    constructor(props) {
        super(props);
        this.state = {
          showButtonList: false,
        }
    }
  
    handleClick=(e)=>{
      e.stopPropagation() // 阻止事件冒泡
      this.setState(prevState => ({
        isToggleOn: !prevState.isToggleOn
      }))
        this.setState({
            showButtonList: !this.state.showButtonList,
        })
    }


    // 编辑详情
    handelEdit = (activeId) => {
      const { onHandelEdit } = this.props;
      if (onHandelEdit) {
        onHandelEdit(activeId);
      }
    }
    // 进入报名二维码
    handelSignUp = (activeId) => {
      const { onChangeSignUp } = this.props;
      if (onChangeSignUp) {
        onChangeSignUp(activeId);
      }
    }
    // 进入签到二维码
    handelSignIn = (activeId) => {
      const { onChangeSignIn } = this.props;
      if (onChangeSignIn) {
        onChangeSignIn(activeId);
      }
    }

    //未开始活动btn文案区分
    getCurBtnList = (btnList, examineStatus) => {
      const { signInBtnShow } = this.props;
      let curBtnList = [];
      // 0审核未通过 1审核通过
      if (examineStatus === 1) {
        curBtnList =  btnList.filter((item) => {
          const { id } = item;
          return id !== 3;
        })
      } else if (examineStatus === 0){
        curBtnList =  btnList.filter((item) => {
          const { id } = item;
          return id !== 2;
        });
      }
      if (!signInBtnShow) {
        curBtnList.splice(1,1)
      }
      
      return curBtnList
      
    }
    // 进入联系人管理列表
    intoContactsInfo = (id) => {
      const { onIntoContactsInfo } = this.props;
      if(onIntoContactsInfo) {
        onIntoContactsInfo(id);
      }
    }

  render () {
    const {prefix = 'com-activebutton',showdetail, btnList, examineStatus, activeType, activeId, verifyliststat }=this.props;
    const curBtnList = (activeType === 1) ? this.getCurBtnList(btnList, examineStatus) : btnList;
    const { showButtonList } = this.state;
    return (
      <View className={prefix}>
        {
          showdetail && (
            <View className={`${prefix}-detail`} >
                <View className={`${prefix}-detail-item`} onClick={this.handleClick}>
                    <MJIcon
                      className={`${prefix}-detail-icon`}
                      type='hdlu_sousuobeifen'
                      size={56}
                      color='#C9CED6'
                    >
                    </MJIcon>
                </View>
              {
                  showButtonList && ( 
                  <View className={`${prefix}-detail-info`}>
                    <View className={`${prefix}-detail-info-item`} onClick={this.handelEdit.bind(this, activeId)}>编辑活动</View>
                    <View className={`${prefix}-detail-info-item`} onClick={this.handelSignUp.bind(this, activeId)}>报名二维码</View>
                    <View className={`${prefix}-detail-info-item`}onClick={this.handelSignIn.bind(this, activeId)}>签到二维码</View>
                    </View>)
                }
            </View>
          )
        }
        <View className={`${prefix}-buttons`}>
          {
            curBtnList && curBtnList.length > 0 ? (
              curBtnList.map((item) => {
                const { id, text } = item;
                return (
                  <View onClick={this.intoContactsInfo.bind(this, id)} key={id} className={`${prefix}-buttons-btn`}>
                    <View className={`${prefix}-buttons-btn-text`}>{text}</View>
                    {
                      verifyliststat === 1 && id === 2 ? (
                        <View className={`${prefix}-buttons-btn-point`}>·</View>
                      ) : null
                    }
                  </View>
                )
              })
            ) : null
          }
        </View>
      </View>
        
    
    )
  }
}

export default ActiveButton;