import Taro, { Component } from '@tarojs/taro';
import { View, Input } from '@tarojs/components';
import MJIcon from '../MJIcon';
import './index.scss';

const noop = () => {};

class MJSearch extends Component {
  static defaultProps  = {
    prefix: 'com-search',
    placeholder:'',
    type:'text',
    value:'',  
    maxLength:'',
    disabled:false,
    onInputChange: noop,
    onInputClick: noop,
    
  }
  handelChange = e => {
    const { onInputChange } = this.props;
    onInputChange(e.target.value);
  }

  handleClick = () => {
    // const { onInputClick } = this.props;
    // onInputClick();
  }

  enterClick = () => {
    const { onInputClick } = this.props;
    onInputClick();
  }
  
  render () {
    const {
      prefix,
      placeholder,
      type,
      value,
      maxLength,
      disabled,  
      
    } = this.props;
   
    return (
      <View className={prefix}>
         <View className={`${prefix}-search`}>
          <MJIcon 
            type='hdlu_sousuo'
            size={40}
            color='#C9CED6'
            onClick={this.enterClick}
          >
          </MJIcon>
         </View> 
          <Input
            className={`${prefix}-input`}
            placeholder={placeholder}
            type={type}
            value={value}
            disabled={disabled}
            maxLength={maxLength}
            placeholderClass={`${prefix}-placeholder`}
            onInput={this.handelChange}
            onClick={this.handleClick}
            onConfirm={this.enterClick}
          />      
      </View>
    )
  }
}

export default MJSearch