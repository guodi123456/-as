import Taro, { Component } from '@tarojs/taro';
import { Icon } from '@tarojs/components';
import classnames from 'classnames';
import './index.scss';

const noop = () => {};

class MJIcon extends Component {
  static defaultProps = {
    prefix: 'com-mjicon',
    type: '',
    size: 24,
    color: '#000000',
    extraStyle: {},
    disabled: false,
    onClick: noop,
  }

  getIconStyle = () => {
    const { size, color, extraStyle } = this.props;
    return {
      fontSize: `${size}rpx`,
      color,
      ...extraStyle,
    };
  }

  getIconClass = () => {
    const { prefix, type } = this.props;
    return classnames(prefix, {
      iconfont: true,
      [`icon-${type}`]: !!(type),
    });
  }

  handleClick = (e) => {
    const { disabled } = this.props;
    if (disabled) return false;
    this.props.onClick(e);
  }

  render () {
    const { type } = this.props;

    if (!type) {
      return null;
    }

    return (
      <Icon
        style={this.getIconStyle()}
        className={this.getIconClass()}
        onClick={this.handleClick}
      />
    );
  }
}

export default MJIcon;
