import Taro, { Component } from '@tarojs/taro';
import { View, Button } from '@tarojs/components';
import { MJIcon } from '../MJIcon';
import './index.scss';

const noop = () => {};

class MJInput extends Component {
  static defaultProps = {
    prefix: 'com-mjbutton',
    text: '',
    onButtonClick: noop,
  }

  handleClick = () => {
    const { onButtonClick } = this.props;
    onButtonClick();
  }

  //  获取样式
  getStyle = () => {
    const { color, width } = this.props
    return {
      color,
      width,
    }
  }


  render () {
    const { prefix = 'com-mjbutton', text, disabled } = this.props;
    return (
      <View className={prefix}>
        <Button
          onClick={this.handleClick.bind(this)}
          className={`${prefix}-btn`}
          style={this.getStyle()}
          disabled={disabled}
        >
          {text}
        </Button>
      </View>
    );
  }
}

export default MJInput;
