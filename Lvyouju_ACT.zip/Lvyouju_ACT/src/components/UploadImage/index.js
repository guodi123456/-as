import Taro, { Component } from '@tarojs/taro'
import { View,Image } from '@tarojs/components'
import { MJIcon } from '../MJIcon'
import './index.scss'

class UploadImage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      pic:'',
      titleText:'',
      color:'#eb0911',
      clicked: false,
    }
}

static defaultProps = {
  prefix: 'com-uploadImage',
}
  handleuploadImage = () => {
      const self=this;
      const titleType = self.getTitleType();
      const changeImageUrl = self.changeImageUrl;
      Taro.chooseImage({
          count: 1,
          sizeType: ['original', 'compressed'],
          sourceType: ['album', 'camera'],
          success(res){
            const { tempFilePaths } = res || {};  
            const qid = Date.now();
            Taro.showLoading({
              title: '上传中...',
            });
            Taro.uploadFile({
              url: `https://st.mioji.com/api/?type=api00002&qid=${qid}` ,
              filePath: tempFilePaths[0],
              name: 'file',
              header: {
                'Accept': 'application/json',
                'content-type': 'multipart/form-data',
                'miojitoken': 'miojitoken',
              },
              formData: {
                type: 'api00002',
                file: tempFilePaths[0],
                query: JSON.stringify({
                  mode: -64,
                }),
                uid: '',
              },
              success(resp){
                  Taro.hideLoading();
                  let data = resp && resp.data;
                  if (typeof data === 'string') {
                    try {
                      data = JSON.parse(data);
                    } catch (error) {
                      data = {};
                    }
                  }
                  self.setState({
                      pic: tempFilePaths[0],
                      color:'#ffffff',
                      titleText:`${titleType ? '替换头像' : '替换图片'}`,
                      clicked:true
                  })                  
                changeImageUrl(data.data.url); 
              }                
            })
          }
      })
  }
  

  changeImageUrl = (value) => {
    const { onChangeImage } = this.props;
    if(onChangeImage) {
      onChangeImage(value)
    }
  }

  getTitleType = () => {
    const { titleType } = this.props;
    return titleType
  }

  render () {
    const { prefix = 'com-uploadImage', desc, title, img } = this.props;
    const { pic,titleText,color,clicked }=this.state;
    const style= clicked ===true?{border:`none`}:{border: `2rpx dashed #c9ced6`}
    return (
      <View  className={prefix} onClick={this.handleuploadImage.bind(this)} style={style}>
       <View className={`${prefix}-info`}>
        <View className={`${prefix}-info-image`}>
          <MJIcon 
            type='hdlu_tupian'
            color={img ? '#ffffff' : color} 
            size={60}
          />
        </View>
        <View className={`${prefix}-info-title ${img ?  `${prefix}-info-titlecol`: ''}`}>
          { titleText || title}
        </View>
        {
          desc ? (
            <View className={`${prefix}-info-desc ${img ?  `${prefix}-info-titlecol`: ''}`}>
              建议上传图片比例为 横向 16:9
            </View>
          ) : null
        }
        </View>
        {
          img || pic ? (
            <Image 
              className={`${prefix}-picture`}
              src={img || pic}
            />
          ) : null
        }
      </View>
    )
  }
}

export default UploadImage

