import Taro, { Component } from '@tarojs/taro';
import { View, Text } from '@tarojs/components';
import { MJIcon } from '../MJIcon';
import { navigatoDetail, formatPeopleInfo } from '../../utils';
import { CheckBox } from '../../components';
import './index.scss';

class MemberItem extends Component {

  constructor(props) {
      super(props);
      this.state = {
      }
  }

  static defaultProps = {
    prefix: 'com-memberitem',
    showcheckbox:true,
    showText:true,
    showinfo:'选择全部',
    data:{},  

  }
    
  LinkTo = (id, aid) => {
    navigatoDetail(id, aid)
  }
  render () {
    const { prefix = 'com-memberitem',showcheckbox,showinfo,checked,disabled,showText, value, data, onHandleCange, activeType, activeId }=this.props;
    let infoObj = formatPeopleInfo(data);
    return (
      <View className={prefix}>
         <View className={`${prefix}-item`}>
            {
              showcheckbox &&(
                <View className={`${prefix}-item-checkbox`}>
                  <CheckBox 
                    value={value}	
                    checked={checked}
                    disabled={disabled}
                    onCheckChange={onHandleCange}
                  />
                </View>
              )
            }  
            {
              showText===true?
                <View className={`${prefix}-item-info`}
                  onClick={this.LinkTo.bind(this, value, activeId)}
                >
                   <View className={`${prefix}-item-info-left`}>
                     <View className={`${prefix}-item-info-left-top`}>
                        <Text className={`${prefix}-item-info-top-name`}>{ infoObj[1] }</Text>
                        <Text className={`${prefix}-item-info-top-profession`}>{ infoObj[4] }</Text>
                      </View>
                      <View className={`${prefix}-item-info-left-top`}> 
                         <Text className={`${prefix}-item-info-top-telephone`}>{ infoObj[2] }</Text>
                         <Text className={`${prefix}-item-info-top-travelagency`}>{ infoObj[3] }</Text>
                      </View>
                     </View> 
                 
                    <View className={`${prefix}-item-info-right`}>
                       <MJIcon 
                         type='hdlu_tiaozhuan'
                         size={56}
                         color='#C9CED6'
                       />
                     </View>
                 </View>
                :
               <Text className={`${prefix}-item-showinfo`}>{showinfo}</Text>
             }
           </View>
       </View>  
    )
  }
}

export default MemberItem;