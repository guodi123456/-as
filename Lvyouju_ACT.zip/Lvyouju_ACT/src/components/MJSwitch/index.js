import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import './index.scss'

/*
 * @params
 *   checked  是否打开
 *   onChangeSw 获取状态事件
 */
class MJSwitch extends Component {
  static defaultProps = {
    prefixCls: 'mj-switch',
    onChangeSw: () => {}
  }

  constructor(props) {
    super(props)
    this.state = {
      open: this.props.checked
    }
  }

  switchClick = () => {
    const { open } = this.state;
    const { onChangeSw } = this.props;
    this.setState({
      open: !open
    })
    onChangeSw(!open);
  }

  render() {
    const { prefixCls } = this.props
    const { open } = this.state
    return (
      <View className={`${prefixCls}`}>
        <View
          className={`${prefixCls}-wrap ${open ? 'mj-switch-open' : 'mj-switch-close'}`}
          onClick={this.switchClick.bind(this)}
        >
          <View
            className={`${prefixCls}-wrap-cycle ${!open ? 'mj-switch-open mj-switch-left' : 'mj-switch-close mj-switch-right'}`}
          >
          </View>
        </View>
      </View>
    )
  }
}

export default MJSwitch