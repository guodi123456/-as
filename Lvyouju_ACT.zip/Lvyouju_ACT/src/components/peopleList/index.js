import Taro, { Component } from '@tarojs/taro';
// import { connect } from '@tarojs/redux';
import { View, Text } from '@tarojs/components';
import _ from 'lodash';
import { MJSearch, MemberItem } from '../../components';
// import { requestContactInfo } from "../../actions/actives";
import './index.scss';

class PeopleList extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }
    static defaultProps = {
      prefix: 'people-list',
    }

  componentWillMount () {}

  componentDidShow () { }

  componentDidHide () { }
  render () {
    const { prefix='people-list', people_list, num, title, onInputChange, onInputClick, isSearched, activeId } = this.props;
    
    return (
      <View className={prefix}>
          <View className={`${prefix}-content`}>
            <View className={`${prefix}-content-search`}>
              <MJSearch 
                placeholder='按姓名、手机号、公司名称搜索'
                type='text'
                value=''
                maxLength={25}
                onInputChange={onInputChange}
                onInputClick={onInputClick}
              />
            </View>
            <View className={`${prefix}-content-checkAll`}>
              <Text className={`${prefix}-content-checkAll-title`}>{title}人数（共{num ? num : 0}人）</Text>
            </View>
            <View className={`${prefix}-content-newPerson`}>
              {
                people_list && people_list.length > 0 ? (
                  <View className={`${prefix}-content-newPerson-list`}>
                    <View className={`${prefix}-content-box`}></View>
                    {
                      people_list.map((item, index) => {
                        const { csuid, content } = item;
                        return (
                          <MemberItem
                            key={index}
                            show={1}
                            showcheckbox={false}
                            data={content}
                            value={csuid}
                            activeId={activeId}
                          > 
                          </MemberItem>
                        )
                      })
                    }
                  </View>
                ) : (
                  <View className={`${prefix}-none`}>{isSearched ? '未找到相关信息' : `暂无${title}的人员`}</View>
                )
              }
            </View>
          </View>
      </View>
    )
  }
}

export default PeopleList
