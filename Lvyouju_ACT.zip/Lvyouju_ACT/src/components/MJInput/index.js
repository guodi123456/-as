import Taro, { Component } from '@tarojs/taro';
import { View, Text, Input } from '@tarojs/components';
import { MJIcon } from '../MJIcon';
import './index.scss';

const noop = () => {};

class MJInput extends Component {
  static defaultProps = {
    prefix: 'com-mjinput',
    label: '',
    placeholder: '',
    option: '',
    value: '',
    style:'',
   
  
    maxLength: 150,
    disabled: false,
    required: false,
    show:false,
    showpassword:false,
    onInput: noop,
    onClick: noop,
    onInputClick: noop,
    onShowPassword: noop,
    onInputChange: noop,
  }
  constructor(props) {
    super(props);
    this.state = {
      wordnumber: 0,
    }
}

  handelChange = e => {
    const { onInputChange } = this.props;
    onInputChange(e);
    this.setState({
      wordnumber: e.target.value.length
    })

  }

  handleClick = () => {
    const { onInputClick } = this.props;
    onInputClick();
  }

  handleConfirm = () => {
    const {onInputConfirm} = this.props;
    if (onInputConfirm) {
      onInputConfirm();
    }
  }
  handleShowPassword = () => {
    const { type, onHandelChangeType } = this.props;
    if(onHandelChangeType) {
      onHandelChangeType(type);
    }
    
  }

  render () {
    const {
      prefix,
      label,
      placeholder,
      value,
      maxLength,
      disabled,
      required,
      showNumber,
      showpassword,
      show,
      style,
      maxnumber,
      errorStyle,
      type,
    } = this.props;
    const { wordnumber }=this.state;

    return (

      <View className={prefix}>
        { show &&
          <Text className={`${prefix}-label`}>{label}</Text>
        }
        { required && (
          <Text className={`${prefix}-required`}>*</Text>
        )}
        <View 
          className={`${prefix}-box ${errorStyle ? 'errorStyle' : ''} ${label ? 'margin-lft' : ''}`}
          style={style}
        >
          <Input
            className={`${prefix}-box-input`}
            placeholder={placeholder}
            value={value}
            disabled={disabled}
            maxLength={maxLength}
            placeholderClass={`${prefix}-box-placeholder`}
            onInput={this.handelChange}
            onClick={this.handleClick}
            password={type === 'password'}
          />
          {
            showpassword && (
              <View className={`${prefix}-eye`}>
                <MJIcon
                  type={type === 'text' ? 'hdlu_chakan' : 'hdlu_bukejian'}
                  size={40}
                  color='#C9CED6'
                  onClick={this.handleShowPassword.bind(this)}
                >

                </MJIcon>
              </View>
            )
          }
         {
            showNumber && (<View className={`${prefix}-box-wordnumber`}>{wordnumber === 0 ? value.length : wordnumber}/{maxnumber}</View>)

          }
        </View>
        <View>
        
        </View>
      </View>
    );
  }
}

export default MJInput;
