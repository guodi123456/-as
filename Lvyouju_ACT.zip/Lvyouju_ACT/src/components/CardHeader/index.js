import Taro, { Component } from '@tarojs/taro';
import { View } from '@tarojs/components';
import './index.scss';

const noop = () => {};

class CardHeader extends Component {
  static defaultProps = {
    prefix: 'com-cardheader',
    title: '',
    tip: '',
    color: '',
    onClick: noop,
  }

  handleClick = () => {
    const { disabled } = this.props;
    if (!disabled) {
      this.props.onClick();
    }
  }

  render () {
    const { prefix, title, tip, color, tagType} = this.props;
    
    return (
      <View className={prefix} onClick={this.handleClick}>
        <View
          className={`${prefix}-square`}
          style={{ backgroundColor: color }}
        />
        <View className={`${prefix}-title`}>{title}</View>
        {Boolean(tip) && (
          <View className={`${prefix}-tip`}><View className={`${prefix}-tip-round color${tagType}`}></View>{tip}</View>
        )}
        
      </View>
    );
  }
}

export default CardHeader;
