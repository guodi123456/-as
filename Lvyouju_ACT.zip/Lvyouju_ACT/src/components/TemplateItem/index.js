import Taro, { Component } from '@tarojs/taro';
import { View, Image} from '@tarojs/components';
import MJIcon from '../MJIcon';
import photo from '../../assets/image/touxiang.png';

import  './index.scss';

class TemplateItem extends Component {
    static defaultProps = {
        prefix: 'com-templateitem',
        type: 3,
        name:'刘某',
        profession:'某酒店行业资深专家',
        telephone: '1232154325'
      }
      constructor(props) {
        super(props);
        this.state = {
          curType: '',
           
        }

    }
   handleClick(type){
    const { onGetModalType } = this.props;
    this.setState({
      curType: type
    })
    if (onGetModalType) {
      onGetModalType(type)
    }
   }
 
  render () {
    const {prefix = 'com-templateitem',type,name,telephone,profession, selectType }=this.props
    return (
      <View>
        {
          type === 0 ?
          <View className={`${prefix} ${selectType === 0 ? 'curStyle' : ''}`} onClick={this.handleClick.bind(this, 0)}>
            <View className={`${prefix}-item`}>
              <View className={`${prefix}-item-left`}>
                  <Image 
                    className={`${prefix}-item-left-image`}
                    src={photo} 
                  />
                <View className={`${prefix}-item-left-text`}>
                  <View className={`${prefix}-item-left-text-name`}>{name}</View>
                  <View className={`${prefix}-item-left-text-profession`}>{profession}</View>
                </View>
            </View>
              <View className={`${prefix}-item-button`}>
                  <MJIcon
                    type={selectType === 0 ? 'hdlu_xuanzhong' : 'hdlu_weixuanzhong'} 
                    size={40}
                    color={selectType === 0 ? '#eb0911' : '#c9ced6'}
                  />
                </View>
          </View>
        </View>:
          type=== 1 ?
        <View className={`${prefix} ${selectType === 1 ? 'curStyle' : ''}`}  onClick={this.handleClick.bind(this, 1)} >
            <View className={`${prefix}-item`}>
              <View className={`${prefix}-item-left`}>
                  <View className={`${prefix}-item-left-text`}>
                      <View className={`${prefix}-item-left-text-name`}>姓名: {name}</View>
                      <View className={`${prefix}-item-left-text-profession`}>联系方式: {telephone}</View>
                  </View>
                </View>
              <View className={`${prefix}-item-button`}>
                    <MJIcon
                      type={selectType === 1 ? 'hdlu_xuanzhong' : 'hdlu_weixuanzhong'} 
                      size={40}
                      color={selectType === 1 ? '#eb0911' : '#c9ced6'}
                    />
                  </View>
          </View>
        </View>:
        <View className={`${prefix} ${selectType === 2 ? 'curStyle' : ''}`}  onClick={this.handleClick.bind(this, 2)} >
          <View className={`${prefix}-typethree-title`}>自定义图文</View>
          <View className={`${prefix}-typethree-button`}>
            <View className={`${prefix}-typethree-button-icon`}>
              <MJIcon
                type={selectType === 2 ? 'hdlu_xuanzhong' : 'hdlu_weixuanzhong'} 
                size={40}
                color={selectType === 2 ? '#eb0911' : '#c9ced6'}
              />
            </View>
          </View>
        </View>
      }
      </View>        
    )
  }
}

export default TemplateItem