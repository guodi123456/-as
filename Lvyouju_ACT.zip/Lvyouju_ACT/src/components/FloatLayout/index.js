import Taro, { Component } from '@tarojs/taro'
import { View } from '@tarojs/components'
import _ from 'lodash'
import { ActiveProcess, AddButton } from '../../components'
import dateFormater from '../../utils/formatDate';
import './index.scss'

class FloatLayout extends Component {

  static defaultProps = {
    isOpened: false,
    onClose: Function,
    title: String,
    prefix: 'flolayout',
}

  handleClose () {
      this.props.onClose()
  }

  leftIconClick = (openIndex, index) => {
    const { onLeftIconClick } = this.props;
    onLeftIconClick(openIndex, index)
  }

  rightIconClick = (openIndex, index) => {
    const { onRightIconClick } = this.props;
    onRightIconClick(openIndex, index)
  }

  //  确认排序
  onAddProcess = (option) => {
    this.props.onClose(option)
  }

  render () {
    const {isOpened, prefix = 'flolayout', openIndex, data, option } = this.props;
    if (!data) return;
    const dataItem = data[openIndex];
    const list = _.get(dataItem, 'list', []);
    const date = _.get(dataItem, 'date', '');
    const module_type = _.get(dataItem, 'module_type', '');
    return (
        <View className={isOpened ? `${prefix} active` : prefix} catchtouchmove='return'>
          <View class='shadow' catchtouchmove='return'></View>
          <View className={`${prefix}-overlay`} onClick={this.handleClose.bind(this)}></View>
          <View className={`${prefix}-container`}>
            <View className={`${prefix}-container-icon`}></View>
            <View className={`${prefix}-container-body`}>
              <View className={`${prefix}-container-body-content`}>
                {
                  date ? (
                    <View className={`${prefix}-container-body-content-date`}>
                      {dateFormater(date, ['年', '月', '日'])}
                      </View>
                  ) : null
                }
                {
                  option === 'module' ? (
                    <View className={`${prefix}-container-body-content-item`}>
                      {
                        list && list.length > 0 && module_type === 0 ? (
                          <View className={`${prefix}-info-process-content`}>
                            {
                              list.map((item, index) => {
                                const { name, img,  desc } = item;
                                return (
                                  <ActiveProcess
                                    key={index}
                                    pointNum={false}
                                    headerImg={img}
                                    titleName={name}
                                    content={desc}
                                    iconType={1}
                                    onLeftIconClick={this.leftIconClick.bind(this, openIndex, index)}
                                    onRightIconClick={this.rightIconClick.bind(this, openIndex, index)}
                                    isFirst={index === 0}
                                    isLast={index === list.length - 1}
                                  >
                                  </ActiveProcess>
                                )
                              })
                            }
                          </View>
                        ) : null
                      }
                      {
                        list && list.length > 0 && module_type === 1 ? (
                        list.map((item, index)=> {
                          const { name: moduleName, phone} = item;
                          return (
                            <ActiveProcess
                              key={index}
                              pointNum={false}
                              titleName={moduleName}
                              tel={phone}
                              iconType={1}
                              isFirst={index === 0}
                              isLast={index === list.length - 1}
                              onLeftIconClick={this.leftIconClick.bind(this, openIndex, index)}
                              onRightIconClick={this.rightIconClick.bind(this, openIndex, index)}
                            ></ActiveProcess>
                          )
                        })
                        ) : null
                      }
                    </View>
                  ) : (
                    <View className={`${prefix}-container-body-content-item`}>
                      {
                        list && list.length > 0 ? (
                          <View className={`${prefix}-info-process-content`}>
                            {
                              list.map((item, index) => {
                                const { start_time: startTime, end_time: endTime, define, title: flowTitle } = item;
                                return (
                                  <ActiveProcess
                                    key={index}
                                    pointNum={index + 1}
                                    startTime={startTime}
                                    endTime={endTime}
                                    subContent={define}
                                    content={flowTitle}
                                    iconType={1}
                                    onLeftIconClick={this.leftIconClick.bind(this, openIndex, index)}
                                    onRightIconClick={this.rightIconClick.bind(this, openIndex, index)}
                                    isFirst={index === 0}
                                    isLast={index === list.length - 1}
                                  >
                                  </ActiveProcess>
                                )
                              })
                            }
                          </View>
                        ) : null
                      }
                    </View>
                  )
                }
              </View>
              <View className={`${prefix}-container-body-btn`}>
                <AddButton
                  title='确认排序'
                  type='confirm'
                  icon={false}
                  onAddActive={this.onAddProcess.bind(this, option)}
                />
              </View>
            </View>
          </View>
        </View>
    )
  }
}

export default FloatLayout